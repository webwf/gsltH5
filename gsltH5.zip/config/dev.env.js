'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  // API_HOST:"http://222.240.163.135"
  // API_HOST:"http://172.16.99.230"
})
