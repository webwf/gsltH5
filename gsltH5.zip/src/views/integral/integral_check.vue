
<template>
  <div style='position:relative' class='f_16'>
    <div class='mask'></div>
    <div class='search'>
      <van-search
        v-model="kw"
        shape='round'
        background='#ffffff'
        placeholder="根据姓名查询"
        right-icon=''
        @search="onSearch"
      />

      <div class='ckeck_box flex flex_between' style='padding:10px 20px 10px 25px'>
        <div>
          <van-checkbox icon-size='15' v-model="checkedAll" @click='isCheckedAll'>全选</van-checkbox>
        </div>
        <div>
          <van-button plain type="info" size="small" @click='checkAll'>批量通过</van-button>
        </div>
      </div>
    </div>

    

    <div class='bg_gray'>

      



      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
      >
        <van-checkbox-group v-model="result">
            

        <div v-for="(item,i) of list" :key='i' class='detail_item'>
          <!-- 1 -->
          <div class='flex flex_between row1'>
            <div class='w_10'>
              <van-checkbox icon-size='15'  :name='item.ID' ref="checkboxes" @click="toggle(i)" >
              </van-checkbox>
            </div>
            
            <div class='dark f_12 bold flex flex_between w_88'>
              
              <div>
                <span>VIN:</span>
                <span>{{item.VIN}}</span>
              </div>

              <div>
                <van-button plain type="info" size="mini" @click='checkOne(i)'>审批通过</van-button>
              </div>

            </div>
            
          </div>

          <!-- 2 -->
          <div class='row1 flex flex_between'>
            <div class='w_10' > </div>
            <div class='w_88 f_11'>

              <van-row>
                <van-col span="12" class='text_l'>
                  <div>姓名：{{item.name}}</div>
                </van-col>
                <van-col span="12">
                  <div>职位：{{item.title}}</div>
                </van-col>
              </van-row>

              <van-row class='m_t_10'>
                <van-col span="12" class='text_l'>
                  <div>积分：<span class='f_15 blue'>{{item.score}}</span></div>
                </van-col>
                <van-col span="12">
                  <div>生成时间:{{item.time}}</div>
                </van-col>
              </van-row>

            </div>

          </div>



        </div>

        </van-checkbox-group>
        
      </van-list>



    </div>
  </div>
</template>

<script>

import Vue from 'vue';

import { Search,List,Checkbox,CheckboxGroup ,Button ,Row ,Col,Toast ,Dialog ,Notify  } from 'vant';
Vue.use(Search).use(List).use(Checkbox).use(CheckboxGroup).use(Button).use(Row).use(Col).use(Toast).use(Dialog).use(Notify);



export default {
  name: 'Tab1',  // 统计表
  data () {
    return {
      haveNoneMsg : '没有数据',
      errMsg : '获取数据失败',
      checkErrMsg : '审批失败',
      checkSuccMsg : '审批通过',

      kw : '',
      loading: false,
      finished: false,

      checkedAll : false,
      result:[],

      params:{
        pno:1,
        keywords:'',
      },

      list: [
        // {ID:1111,VIN:'GJLENMKF',name:'张三',title:'总经理',score:500,time:'2019-08-30',checked:false},
        // {ID:2222,VIN:'FHJFGNVB',name:'张三2',title:'总经理1',score:5500,time:'2029-08-30',checked:false},
        // {ID:3333,VIN:'TGRFTYBK',name:'张三3',title:'总经理2',score:1500,time:'2039-08-30',checked:false},
        // {ID:4444,VIN:'YJFFGAVC',name:'张三4',title:'总经理3',score:2500,time:'1019-05-30',checked:false},
        // {ID:5555,VIN:'GJLENMKF',name:'张三',title:'总经理',score:500,time:'2019-08-30',checked:false},
        // {ID:6666,VIN:'FHJFGNVB',name:'张三2',title:'总经理1',score:5500,time:'2029-08-30',checked:false},
        // {ID:7777,VIN:'TGRFTYBK',name:'张三3',title:'总经理2',score:1500,time:'2039-08-30',checked:false},
        // {ID:8888,VIN:'YJFFGAVC',name:'张三4',title:'总经理3',score:2500,time:'1019-05-30',checked:false},
      ],

      canLoadMore : false,

    }
  },

  computed:{
    //  获得 有效 的 kw
    validKw(){
      return this.kw.replace(/\s+/g,'')
    }

  },

  watch:{
    
  },

  created(){
    //  查询  待 审核 数据

    this.getData(1);

  },

  mounted(){


  },

  methods:{

    //  搜索
    onSearch(){

      if(this.params.keywords != this.validKw){

        this.params = {pno:1,keywords:this.validKw};

        console.log('关键词  变化了  才 搜索',this.params.keywords);

        this.getData(1);
      }      

    },

    //  加载 更多
    onLoad() {

      if(this.canLoadMore == true){
      
        this.params.pno ++;

        // console.log('加载更多 +++ ',this.params);
        this.$http.getIntegralCheckData(this.params).then(res=>{
          console.log('返回  加载更多  待审批 结果 ',this.params,res);

          this.loading = false;

          if(res.length<10){
            this.finished = true;
          }
          res.map(item=>this.list.push(item));

        }).catch(err=>{
          Toast.fail({message: this.errMsg , duration: 1500});
        });

      }else{
        this.loading = false;
      }

    },


    // 多选 审核
    checkAll(){

      if(this.result.length == 0){
        Toast.fail({
          message: '请选择需要\n审批的条目',
          duration: 1500
        });

      }else{

        Dialog.confirm({
          title: '提示',
          message: `确定要审批通过选中的条目吗？`
        }).then(() => {
          // on confirm
          console.log(' 多  选  待审核  ',this.result.toString());
          let data = this.result.toString();

          this.goToCheck(data);
        }).catch(() => {
          // on cancel
        });

      }

    },

    //单选  审核
    checkOne(i){

      Dialog.confirm({
        title: '提示',
        message: `确定要审批通过【${this.list[i].name}】吗？`
      }).then(() => {
        // on confirm
        console.log(' 单  选  待审核  ',this.list[i].ID.toString());
        let data = this.list[i].ID.toString();

        this.goToCheck(data);
      }).catch(() => {
        // on cancel
      });

    },

    //  全选  非 全选
    isCheckedAll(){
      this.checkedAll = !this.checkedAll;
      this.result = [];
      if(!!this.checkedAll){
        for(let tmp of this.list){
          this.result.push(tmp.ID)
        }
      }
    },


    //  切换  单选
    toggle(i) {
      this.$refs.checkboxes[i].toggle();

      setTimeout(()=>{
        if(this.result.length == this.list.length){
          this.checkedAll = true;
        }else{
          this.checkedAll = false;
        }
      },50)
    },


    //  发送请求  请求 审批 
    goToCheck(data){
      console.log('请求审核传过去的数据',data);
      Toast.loading({
        mask: true,
        message: '审批中...',
        duration:10000,
        forbidClick:true,
      });
      this.$http.requestCheck({ids:data}).then(res=>{
        console.log('返回  审批 结果 ',data,'----',res);
        //关闭  loading
        Toast.clear();

        if(res.resultCode && res.resultCode == 200){
          // 如果 审批 成功
          Notify({ type: 'success', message: '审批成功' ,duration:1500 });

          //  重新 刷新 数据  pno 置为 1
          this.params.pno = 1;
          this.getData(2)

        }else{
          //  如果 审批 失败
          // Notify({ type: 'danger', message: '审批失败' ,duration:2000 });
          Notify({ type: 'danger', message: res.errMsg ,duration:2000 });
        }

      }).catch(err=>{
        Toast.fail({message: this.checkErrMsg , duration: 1500});

      });


    },

    // 请求  待 审批 数据
    getData(m){
      // 请求  详情
      this.list = [];
      
      Toast.loading({
        mask: true,
        message: m == 1? this.GLO.loadingMsg:this.GLO.reLoadingMsg,
        duration:10000,
        forbidClick:true,
      });

      this.$http.getIntegralCheckData(this.params).then(res=>{

        this.canLoadMore = true;

        console.log('返回 待审批 结果 111',this.params,res,res.length);
        //关闭  loading
        Toast.clear();

        if(!res){
          Toast.fail({message: this.errMsg , duration: 1500});

        }else{
          if(res.length == 0){
            // this.finished = true;
            Toast.fail({message: this.haveNoneMsg , duration: 1500});
          }else{
            if(res.length<10){
              this.finished = true;
            }else{
              this.finished = false;
            }
            res.map(item=>this.list.push(item));
          }
        }

      }).catch(err=>{
        Toast.fail({message: this.errMsg , duration: 1500});
      });
    }
      
  },

}
</script>

<style scoped>

  .small_font{
    /* display:block */
    font-size:12px;
    -webkit-transform:scale(0.833);
    -moz-transform:scale(0.833);
    -o-transform:scale(0.833);
    transform:scale(0.833);
  }
  .small{
    font-size:10px;
  }
  .bold{font-weight: bold}
  .blue{
    color:#2C87D1;
  }
  .bg_gray{
    background-color: #eee;
    min-height:100vh;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    padding:104px 10px 10px;
  }
  .search{
    position: fixed;
    top:0;
    width:100%;
    height:104px;
    background-color: #fff;
    z-index:1000;
  }
  .mask{
    position: absolute;
    top:0;
    width:100%;
    height:104px;
    background-color: #fff;
    z-index:100;
  }
  
  .t_c{text-align:center}
  .flex{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .flex_between{
    justify-content: space-between;
  }
  .flex_around{
    justify-content: space-around;
  }
  .flex_end{
    justify-content: flex-end;
  }
  .row1{
    border-bottom:1px solid #f5f5f5;
    padding:10px 5px;
  }
  .row3{
    padding:10px 5px;

  }
  .detail_item{
    margin-top:10px;
    padding:0 10px;
    background-color: #fff;
    border-radius:5px;
  }
  .f_11{font-size: 11px;}
  .f_12{font-size: 12px;}
  .f_13{font-size: 13px;}
  .f_14{font-size: 14px;}
  .f_15{font-size: 15px;}
  .f_16{font-size: 16px;}
  .f_22{font-size: 22px}
  .dark{color:#666}
  .gray{color:#aaa}
  .w_10{width:10%}
  .w_88{width:88%}

  .text_l{
    text-align: left
  }
  .m_t_10{margin-top:10px;}
  /* .text_r{
    text-align: right
  } */





</style>


