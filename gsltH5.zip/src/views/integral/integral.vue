
<template>
  <div class='container bg_gray'>

    <van-row gutter="10">
      <van-col :span="hasPermit!=0?8:12" >
        <div class='box' @click='jumpToDetail'>
          <div class='h_40 flex integral_title1' >总积分</div>
          <div class='h_50 flex integral_title2 blue'>{{data.totalIntegral}}</div>
        </div>
      </van-col>
      <van-col :span="hasPermit!=0?8:12" >
        <div class='box'>
          <div class='h_40 flex integral_title1'>下月失效积分</div>
          <div class='h_50 flex integral_title2 '>{{data.clearIntegral}}</div>
        </div>
      </van-col>
      <van-col span="8" v-if='hasPermit!=0'>
        <div class='box' @click='jumpToCheck'>
          <div class='h_40 flex integral_title1'>待审核条目</div>
          <div class='h_50 flex integral_title2 '>{{data.auditNum}}</div>
        </div>
      </van-col>
      
    </van-row>

    <van-row gutter="10" class='m_t_10'>
      <van-col :span="hasPermit!=0?8:12" >
        <div class='box' @click='jump(1)'>
          <div class='h_40 flex integral_title1'>京东商城</div>
          <div class='h_50 flex integral_title2 '>
            <van-image
              width="43"
              height="35"
              :src="require('../../assets/1.png')"
            />
          </div>
        </div>
      </van-col>

      <van-col :span="hasPermit!=0?8:12" >
        <div class='box' @click='jump(2)'>
          <div class='h_40 flex integral_title1'>苏宁商城</div>
          <div class='h_50 flex integral_title2 '>
            <van-image
              width="43"
              height="35"
              :src="require('../../assets/2.png')"
            />
          </div>
        </div>
      </van-col>
      
    </van-row>


    <div v-show='false'>
      <form :action="jdUrl" method = 'post' id='form1' ref='form'>
        <input type="text" name='accessKey' :value='accessKey'>
        <input type="text" name='extend' :value='extend'>
        <input type="text" name='returnUrl' :value='returnUrl'>
        <input type="text" name='sign' :value='sign'>
        <input type="text" name='timestamp' :value='timestamp'>
        <input type="text" name='uid' :value='uid'>
        <input type="text" name='version' :value='version'>
      </form>
    </div>
  </div>
</template>

<script>

import Vue from 'vue';
// import Axios from 'axios';
// import VueResource from 'vue-resource';
// Vue.use(VueResource);


import { Row, Col ,Toast ,List ,Image  } from 'vant';
Vue.use(Row).use(Col).use(Toast).use(List).use(Image);



export default {
  name: 'Tab1',  // 统计表
  data () {
    return {
      //  是否 有 审批 权限
      hasPermit : 0,
      jdUrl:'',
      
      // isClick:true,
      // 列数
      colNum:3,
      data:{
        // 总积分
        totalIntegral:0,
        // 下月 失效 积分
        clearIntegral:0,
        // 待审核条目
        auditNum:0,
      },

      errMsg:'获取登录信息失败',

      


      accessKey:'',
      extend:'',
      returnUrl:'',
      sign:'',
      timestamp:'',
      uid:'',
      version:'',






    }
  },

  computed:{


  },

  watch:{



  },

  created(){
    this.jdUrl = this.GLO.JdUrl;

    let thisUrl = window.location.href ;
    if(thisUrl.indexOf('?') != -1 && thisUrl.indexOf('?') != thisUrl.length-1 ){
      let str = thisUrl.split('?')[1];
      // console.log('得到地址后面的  参数 字符串 ',str);

      this.GLO.removeCookie('permissions');
      //  将 str  存到 cookie 中
      this.GLO.urlToCookie(str);


    }
    this.hasPermit = this.GLO.getCookie('permissions') || 0;

    console.log('审批 积分 权限值 ',this.hasPermit);
    

    this.$http.getTotalIntegral().then(res=>{
      console.log('获得 总积分 的数据',res);
      this.data = res;

    }).catch(err=>{
      Toast.fail({message: '获取积分信息出错', duration: 1500});
    })





  },

  mounted(){


  },

  methods:{


    jump(n){

      if(n==1){
        console.log('京东');

        Toast.loading({
          mask: true,
          message: this.GLO.jumpMsg ,
          duration:20000,
          forbidClick:true,
        });



        this.$http.getJDParams().then(res=>{

          Toast.clear();

          // console.log(JSON.stringify(res));
          console.log(res);
          // console.log(typeof res);
          
          // debugger
          this.accessKey = res.accessKey;
          this.extend = res.extend;
          this.returnUrl = res.returnUrl;
          this.sign = res.sign;
          this.timestamp = res.timestamp;
          this.uid = res.uid;
          this.version  = res.version;


          if(res){

            console.log(this.uid);

            setTimeout(()=>{
              
              document.getElementById('form1').submit(()=>{
                return true
              })

            },50)

          }

        }).catch(err=>{
          Toast.fail({message: this.errMsg , duration: 1500});
        })

      }else{

        console.log('苏宁');

        Toast.loading({
          mask: true,
          message: this.GLO.jumpMsg,
          duration:20000,
          forbidClick:true,
        });

        this.$http.getSNParams().then(res=>{
          
          console.log(typeof res);
          console.log(res);

          //  跳转到 苏宁
          window.location.href = res;
          Toast.clear();

        }).catch(err=>{
          Toast.fail({message: this.errMsg , duration: 1500});
        })

      }
    },

    //  跳转到 待 审批 check  页面
    jumpToCheck(){
      this.$router.push('/integral/check');
    },
    jumpToDetail(){
      this.$router.push('/integral/detail');
    }
      
  },


}
</script>

<style scoped>
  .bg_gray{
    background-color: #eee;
    min-height:100vh;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }
  .container{
    padding:20px 10px;
  }
  .box{
    /* height:150px; */
    padding:15px 0;
    background-color: #fff;
    border-radius:5px;
  }
  .t_c{text-align:center}
  .flex{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .h_50{
    height:50px;
  }
  .h_30{
    height:30px;
  }
  .integral_title1{
    color:#aaa;
    font-size:12px;
  }
  .integral_title2{
    font-size:24px;
  }
  .blue{
    color:#2C87D1;
  }
  .m_t_10{
    margin-top:10px
  }
  





</style>


