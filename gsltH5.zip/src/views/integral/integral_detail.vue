
<template>
  <div style='position:relative' class='f_22'>
    <div class='mask'></div>
    <div class='search'>
      <van-search
        v-model="kw"
        shape='round'
        background='#ffffff'
        placeholder="根据VIN查询"
        right-icon=''
        @search="onSearch"
      />
    </div>
    <div class='bg_gray'>
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
      >
        <div v-for="(item,i) of list" :key='i' class='detail_item'>
          <!-- 1 -->
          <div class='flex flex_between row1'>
            <div class='dark f_12 bold'>
              <span>VIN:</span>
              <span>{{item.VIN}}</span>
            </div>
            <div class='flex'>
              <span class='blue '>{{item.total}}</span>
              <span class='gray small_font small '>总积分</span>
            </div>
          </div>

          <!-- 2 -->
          <div class='flex flex_around row1'>
            <div>
              <div class='bold dark'>{{item.canUse}}</div>
              <div class='gray small_font small'>可用积分</div>
            </div>
            <div>
              <div class='bold dark'>{{item.used}}</div>
              <div class='gray small_font small'>已用积分</div>
            </div>
            <div>
              <div class='bold dark'>{{item.clear}}</div>
              <div class='gray small_font small'>已清除积分</div>
            </div>
          </div>

          <!-- 3 -->
          <div class='flex flex_end row3 f_12'>
            <span>生效日期:{{item.time}}</span>
          </div>


        </div>
        
      </van-list>



    </div>
  </div>
</template>

<script>

import Vue from 'vue';

import { Search,List,Toast } from 'vant';
Vue.use(Search).use(List).use(Toast);



export default {
  name: 'Tab1',  // 统计表
  data () {
    return {
      haveNoneMsg : '没有数据',
      errMsg : '获取数据失败',
      kw : '',
      list: [
        // {VIN:'JSASDRFG',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'JJFRGGDS',total:900,canUse:500,used:300,clear:100,time:'2019-09-22'},
        // {VIN:'SDGSAGFF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'LAIGQAGF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'LAIGQAGF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'LAIGQAGF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'LAIGQAGF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'LAIGQAGF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'LAIGQAGF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
        // {VIN:'LAIGQAGF',total:500,canUse:400,used:100,clear:0,time:'2019-08-30'},
      ],
      loading: false,
      finished: false,
      params:{
        pno:1,
        keywords:'',
      },

      canLoadMore : false,


    }
  },

  computed:{
    validKw(){
      return this.kw.replace(/\s+/g,'')
    }

  },

  watch:{



  },

  created(){
    // console.log('开始加载');
    this.getData();

  },

  mounted(){


  },

  methods:{
    onSearch(){
      
      // console.log('搜索');

      if(this.params.keywords != this.validKw){

        this.params = {pno:1,keywords:this.validKw};

        console.log('搜索内容 变化了  才 搜索',this.params.keywords);

        this.getData();
      }


    },


    onLoad() {
      // 异步更新数据

      if(this.canLoadMore == true){
        
      
        this.params.pno ++;

        // console.log('加载更多 +++ ',this.params);
        this.$http.getIntegralDetail(this.params).then(res=>{
          console.log('返回  加载更多  结果 ',this.params,res);

          this.loading = false;

          if(res.length<10){
            this.finished = true;
          }
          res.map(item=>this.list.push(item));

          console.log('数据长度',this.list.length);

        }).catch(err=>{
          Toast.fail({message: this.errMsg , duration: 1500});
          
        });

      }else{
        this.loading = false;
      }


    },


    //  加载数据
    getData(){
      // 请求  详情
      this.list = [];
      
      Toast.loading({
        mask: true,
        message: this.GLO.loadingMsg,
        duration:10000,
        forbidClick:true,
      });

      this.$http.getIntegralDetail(this.params).then(res=>{

        this.canLoadMore = true;

        console.log('返回结果 111',this.params,res,res.length);
        // console.log(this.canLoadMore);
        //关闭  loading
        Toast.clear();

        if(!res){
          Toast.fail({message: this.errMsg , duration: 1500});

        }else{
          if(res.length == 0){
            this.finished = true;
            Toast.fail({message: this.haveNoneMsg , duration: 1500});
          }else{
            if(res.length<10){
              this.finished = true;
            }else{
              this.finished = false;
            }
            res.map(item=>this.list.push(item));
          }
        }

      }).catch(err=>{
        Toast.fail({message: this.errMsg , duration: 1500});
      });

    }

      
  },




    


}
</script>

<style scoped>

  .small_font{
    /* display:block */
    font-size:12px;
    -webkit-transform:scale(0.833);
    -moz-transform:scale(0.833);
    -o-transform:scale(0.833);
    transform:scale(0.833);
  }
  .small{
    font-size:10px;
  }
  .bold{font-weight: bold}
  .blue{
    color:#2C87D1;
  }
  .bg_gray{
    background-color: #eee;
    min-height:100vh;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    padding:54px 10px 10px;
  }
  .search{
    position: fixed;
    top:0;
    width:100%;
    height:54px;
    background-color: #fff;
    z-index:1000;
  }
  
  .t_c{text-align:center}
  .flex{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .flex_between{
    justify-content: space-between;
  }
  .flex_around{
    justify-content: space-around;
  }
  .flex_end{
    justify-content: flex-end;
  }
  .row1{
    border-bottom:1px solid #f5f5f5;
    padding:10px 5px;
  }
  .row3{
    padding:10px 5px;

  }
  .detail_item{
    margin-top:10px;
    padding:0 10px;
    background-color: #fff;
    border-radius:5px;
  }
  .f_11{font-size: 11px;}
  .f_12{font-size: 12px;}
  .f_13{font-size: 13px;}
  .f_22{font-size: 22px;}

  .dark{color:#666}
  .gray{color:#aaa}
  .mask{
    position: absolute;
    top:0;
    width:100%;
    height:54px;
    background-color: #fff;
    z-index:100;
  }





</style>


