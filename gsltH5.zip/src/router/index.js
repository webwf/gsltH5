import Vue from 'vue'
import Router from 'vue-router'
import Sales from '@/components/Sales'

import Tab1 from '@/components/tab1'

import Integral from '@/views/integral/integral'
import IntegralDetail from '@/views/integral/integral_detail'
import IntegralCheck from '@/views/integral/integral_check'

Vue.use(Router)

export default new Router({
  // mode:'history',
  base:'/dmscloud.web/html/dist/',
  routes: [
    {
      path: '/',
      name: 'Sales Invoice Summary Report', // 销售统计表
      component: Sales
    },
    {
      path: '/tab1',
      name: 'tab1', // 统计表
      component: Tab1
    },
    {
      path: '/integral',
      name: 'integral', // 积分
      component: Integral
    },
    {
      path: '/integral/detail',
      name: 'integral_detail', // 积分  详情
      component: IntegralDetail
    },
    {
      path: '/integral/check',
      name: 'integral_check', // 积分 审查
      component: IntegralCheck
    },
  ]
})
