import Vue from 'vue'
import App from './App'
import router from './router'
import Vant from 'vant';

import store from './store/index.js'

import 'vant/lib/index.css';



//  引用全局  方法   常量
import global_func from './global.js';
Vue.prototype.GLO = global_func;


import http from './http/api';
Vue.prototype.$http = http;

import Select from './components/Select';
import Chart from './components/Chart';
import Amount from './components/Amount';
import Cars from './components/Cars';
import Source from './components/Source';





Vue.component('my-select-box',Select);
Vue.component('my-chart',Chart);
Vue.component('my-amount',Amount);
Vue.component('my-cars',Cars);
Vue.component('my-source',Source);


Vue.use(Vant);


// import VueResource from 'vue-resource';
// Vue.use(VueResource);

import echarts from 'echarts'
Vue.prototype.$echarts = echarts

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
