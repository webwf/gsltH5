<template>
  <div class="container">

    <van-tabs type="card"  title-inactive-color='#333' color='#1E81D2' @change='changeTabs1'>
      <van-tab title="大区" ></van-tab>
      <van-tab title="省份" ></van-tab>
      <van-tab title="经销商" v-if='userLevel!=3'></van-tab>
    </van-tabs>
    <div class='m_t_20'> 
      <my-select-box :tabNum='tabNum' :userLevel='userLevel' ></my-select-box>
    </div>

    <my-chart :tabNum='tabNum' :userLevel='userLevel'></my-chart>

    <div class='divider'></div>

    <van-tabs type="card"  title-inactive-color='#333' color='#1E81D2' @change='changeTabs2' >
      <van-tab title="绝对量">
        <my-amount :tabNum='tabNum' :userLevel='userLevel' @clone='clone' :finished1 = 'finished1'></my-amount>
      </van-tab>
      <van-tab title="车系">
        <my-cars :tabNum='tabNum' :userLevel='userLevel' @clone='clone' :finished2 = 'finished2'></my-cars>
      </van-tab>
      <van-tab title="来源渠道">
        <my-source :tabNum='tabNum' :userLevel='userLevel' @clone='clone' :finished3 = 'finished3'></my-source>
      </van-tab>
      <!-- <van-tab title="成交量1">
        <div>成交量11111</div>
      </van-tab>
      <van-tab title="成交量2">
        <div>成交量22222</div>
      </van-tab> -->
    </van-tabs>

  </div>
</template>

<script>

import Vue from 'vue';

import { Tab, Tabs, Row, Col ,Toast ,List } from 'vant';
Vue.use(Tab).use(Tabs).use(Row).use(Col).use(Toast).use(List);



export default {
  name: 'Sales',  // 销售统计表
  data () {
    return {
      //  用户 级别 
      // userLevel:-1,
      // tabs1:['大区','省份','经销商'],
      // tabTitle1:'大区',
      tabTitle2:'绝对量',

      tabNum:1,

      canRequest : true,
      // loading1:false,
      finished1:false,
      finished2:false,
      finished3:false,


    }
  },
  computed:{
    params(){
      return this.$store.getters.params
    },
    dataType(){
      return this.$store.getters.dataType
    },
    userLevel(){
      return this.$store.getters.userLevel
    },


  },
  watch:{
    // 监听 参数 有没有变化  有变化  就  调数据  更新 数据  从而更新视图
    'params.time'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    'params.region'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    'params.provice'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    'params.lable'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    'params.seriesId'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    'params.mark'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    'params.dealerCode'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    'params.pageNumber'(){
      this.$store.commit('setPno',1)
      this.getData();
    },
    dataType(){
      this.$store.commit('setPno',1)
      this.getData();
    },
  },
  created(){
    let jwt = '';
    let appRole = '';
		let arr = document.cookie.split("; ");
		// console.log(arr);
		let cookies = [];
		for(let tmp of arr){
		  let key = tmp.split('=')[0];
		  let obj = {};
		  obj[key] = tmp.split('=')[1];
		  cookies.push(obj);
		}
		// console.log(cookies);
		for(let tmp of cookies){
		  if(!!tmp['jwt']){
				jwt = tmp['jwt'];
      }
		  if(!!tmp['appRole']){
				appRole = tmp['appRole'];
      }
    }
    this.$store.commit('setParams',{appRole});
		console.log(jwt);
		console.log(appRole);
    console.log(cookies);

  },

  methods:{
    changeTabs1(name,title){
      // this.tabTitle1 = title;
      this.tabNum = name+1;
      this.$store.commit('setParams',{mark:name+1});
      this.$store.commit('setPno',0);
    },
    changeTabs2(name,title){
      this.tabTitle2 = title;
      this.$store.commit('setDataType',name+1);
      //  改变  tabs
      // console.log('改变了 tabs 2',name+1);
      this.$store.commit('setPno',0);


      
    },

    //  调 数据
    // 1. 调 绝对量 数据
    getData(){
      console.log('params 变化',this.params);

      
      if(this.canRequest){
        this.canRequest = false;
        setTimeout(()=>{
          this.canRequest = true;
          console.log('能否发请求  ',this.canRequest);
        },400);
        //  加载一个  loading
        Toast.loading({
          mask: true,
          message: '加载中...',
          duration:10000,
          forbidClick:true,
        });

        //  根据  当前 是绝对量  车系 渠道   调取 相应 的数据
        if(this.$store.getters.dataType == 1){
          this.$http.getAbs(this.params).then(res=>{
            //关闭  loading
            Toast.clear();
            // this.loading1 = false;

            if(!!res.status){
              console.log('绝对量 数据 ',res.data);
              // console.log('绝对量 数据 ',res.data.length);
              setTimeout(() => {
                
                if(res.data.length<13 && this.tabNum == 3){
                  console.log('绝对量 是否 完成',this.finished1);
                  this.finished1 = true;
                }else{
                  console.log('绝对量 是否 完成',this.finished1);
                  this.finished1 = false;
                }
              }, 100);
              // 把数据 放到 数据 仓库    其他 页面 都用  computed  去仓库 取 
              this.$store.commit('setAbs',res.data)
            }else{
              // 提示 
              Toast.fail('绝对量数据加载失败');
            }
          }).catch(res=>{
            console.log(res);
          })
          

        }
        if(this.$store.getters.dataType == 2){
          this.$http.getSeries(this.params).then(res=>{
            //关闭  loading
            Toast.clear();

            if(!!res.status){
              console.log('++++得到 车系 数据 ++++',res.data);
              console.log('++++得到 车系 数据 ++++',res.data.length);
              setTimeout(() => {
                if(res.data.length<13){
                  this.finished2 = true;
                }else{
                  this.finished2 = false;
                }
              }, 100);
              // 把数据 放到 数据 仓库    其他 页面 都用  computed  去仓库 取 
              this.$store.commit('setSeries',res.data)
            }else{
              // 提示 
              Toast.fail('车系数据加载失败');
            }
          })

        }
        if(this.$store.getters.dataType == 3){
          this.$http.getSrc(this.params).then(res=>{
            //关闭  loading
            Toast.clear();

            if(!!res.status){
              console.log('----- 渠道 数据---',res.data);
              setTimeout(() => {
                if(res.data.length<13){
                  this.finished3 = true;
                }else{
                  this.finished3 = false;
                }
              }, 100);
              // 把数据 放到 数据 仓库    其他 页面 都用  computed  去仓库 取 
              this.$store.commit('setSource',res.data)
            }else{
              // 提示 
              Toast.fail('渠道数据加载失败');
            }
          })

        }

        this.getCompareData();
      }
      

    },



    //  获取 比较 数据
    getCompareData(){

      this.$http.getCompare(this.params).then(res=>{
        if(!!res.status){
          console.log('获取 比较 数据 ',res.data)
          this.$store.commit('setCompareData',res.data)
        }else{
          Toast.fail('比较数据加载失败');
        }

      });

    },

     // 克隆
    clone(obj){
      // console.log('调用 父组件的 clone 方法',obj);
      if(obj === null)return null
      if(Object.prototype.toString.call(obj) === '[object Array]'){
        var newArr = [];
        for(let tmp of obj){
          if(typeof tmp !== 'object'){
            newArr.push(tmp)
          }else{
            newArr.push(this.clone(tmp))
          }
        }
        return newArr;
      }
      var newObj = {};
      for(let key in obj){
        if(typeof obj[key] !== 'object'){
          newObj[key] = obj[key]
        }else{
          newObj[key] = this.clone(obj[key])
        }
      }
      return newObj
    },
    


  }
}
</script>

<style >
.van-tabs--card{padding-top:0}
.van-dropdown-menu__title{
  font-size:12px;
}
.container{
  font-size:14px;
}

.text_c{text-align:center;}
.text_r{text-align:right}
.text_l{ text-align:left }


.f_11{font-size:11px}
.f_12{font-size:12px}
.f_13{font-size:13px}
.f_14{font-size:14px}
.f_15{font-size:15px}
.f_16{font-size:16px}
.f_17{font-size:17px}
.f_18{font-size:18px}

.m_t_4{  margin-top:.04rem; }
.m_t_6{  margin-top:.06rem; }
.m_t_10{  margin-top:.1rem; }
.m_t_20{  margin-top:.2rem; }
.m_t_30{  margin-top:.3rem; }
.m_t_40{  margin-top:.4rem; }

.m_r_10{  margin-right:.1rem; }
.m_r_20{  margin-right:.2rem; }
.m_r_30{  margin-right:.3rem; }
.m_r_40{  margin-right:.4rem; }

.strong{
  font-weight: bold;
}

.flex_row{
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.h-14{
  height:14px;
  line-height:14px;
}





.van-tabs--card>.van-tabs__wrap{
  height:40px;
}
.title-inactive-color{
  height:40px;
  line-height:40px;
}
.van-tabs__nav--card{
  border-radius:5px;
  height:40px;
  line-height:40px;
}
.van-tabs__nav--card .van-tab{
  height:40px;
  line-height:40px;
}
.divider{
  height:8px;
  background-color: #eee;
}






</style>
