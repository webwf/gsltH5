<template>
  <div class='p_10' >
    <div class='m_t_20 f_13 strong text_l flex_row flex_row_start'  v-if='total1!=undefined'>
      <div class='w_33'> {{total1.LABLENAME}}：{{total1.FENMU}} </div>
      <div class='w_33' v-if='userLevel!=1 && tabNum != 1'> {{total2.LABLENAME}}：{{total2.FENMU}} </div>
      <div class='w_33' v-if='userLevel!=1 && tabNum==3 && dealers==1'> {{total3.LABLENAME}}：{{total3.FENMU}} </div>
    </div>
    
    <div  class='m_t_40' v-if='list.length!=0' >
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
        v-if='tabNum==3'
       
      >
        <div v-for="(item,i) of list" :key='i' class='m_t_20 flex_row flex_row_start'>

          <div style='width:7%;margin-right:2%'>
            <div v-if='i==0'>
              <img  alt="冠军" src="../assets/jp1.png" >
            </div>
            <div v-else-if='i==1'>
              <img alt="亚军" src="../assets/jp2.png" >
            </div>
            <div v-else-if='i==2'>
              <img alt="季军" src="../assets/jp3.png" >
            </div>
            <div v-else>
              <span>{{i+1}}</span>
            </div>
          </div>

          <div style='width:85%' >
            <div class='flex_row'>
              <div class='strong'>{{item.LABLENAME}}</div>
              <div class='f_12'>{{item.RATE.toFixed(2)}}%</div>
            </div>
            <div class='flex_row h-14 m_t_10'>
              <div class='bg_blue h-14' :style="{width:item.RATE+'%'}"></div>
              <div class='bg_gray h-14 f_11 text_l' :style="{width:(100-item.RATE)+'%'}" style='padding-left:3px;'>{{item.FENZI}}</div>
            </div>
          </div>

        </div>
      </van-list>

      <div v-else>

      
       <div v-for="(item,i) of list" :key='i' class='m_t_20 flex_row flex_row_start'>

          <div style='width:7%;margin-right:2%'>
            <div v-if='i==0'>
              <img  alt="冠军" src="../assets/jp1.png" >
            </div>
            <div v-else-if='i==1'>
              <img alt="亚军" src="../assets/jp2.png" >
            </div>
            <div v-else-if='i==2'>
              <img alt="季军" src="../assets/jp3.png" >
            </div>
            <div v-else>
              <span>{{i+1}}</span>
            </div>
          </div>

          <div style='width:85%' >
            <div class='flex_row'>
              <div class='strong'>{{item.LABLENAME}}</div>
              <div class='f_12'>{{item.RATE.toFixed(2)}}%</div>
            </div>
            <div class='flex_row h-14 m_t_10'>
              <div class='bg_blue h-14' :style="{width:item.RATE+'%'}"></div>
              <div class='bg_gray h-14 f_11 text_l' :style="{width:(100-item.RATE)+'%'}" style='padding-left:3px;'>{{item.FENZI}}</div>
            </div>
          </div>

        </div>
      </div>


    </div>
  </div>
</template>

<script> 
// FFAD01   FF6A42  2EACEE

export default {
  name: 'Amount',  //  数量 绝对量
  props:['tabNum','userLevel','finished1'],
  data () {
    return {

      // pageNumber:1,
      // list: [],
      loading: false,
      finished: false,

      // len:1000,
      // total:{
      //   FENMU: '',
      //   FENZI: '',
      //   LABLENAME: '',
      //   RANK: '',
      //   RATE: ''
      // },
      // list:[
      //   {
      //     FENMU: '',
      //     FENZI: '',
      //     LABLENAME: '',
      //     RANK: '',
      //     RATE: ''
      //   }
      // ],
      // mark:1,
      // list1:[],
      
    }
  },

  computed:{
    // loading(){
    //   return this.loading1;
    // },

    total1(){
      return this.$store.getters.abs[0]
    },
    total2(){
      return this.$store.getters.abs[1]
    },
    total3(){
      return this.$store.getters.abs[2]
    },
    list(){

      console.log('list列表 变化 ---- ',this.$store.getters.abs.slice(3) );
      return this.$store.getters.abs.slice(3) 
    },
    params(){
      return this.$store.getters.params;
    },
    //  所选  经销商  数量 
    dealers(){
      if(this.params.dealerCode==''){
        // console.log('所选 经销商 长度',0);
        return 0
      }else{
        console.log('所选 经销商 长度',this.params.dealerCode.split(',').length);
        // return this.params.dealerCode.split(',').length
      }

    },

  },
  created(){

  },
  methods:{
    onLoad() {

      // setTimeout(()=>{
        // 异步更新数据
        // 加载状态结束
        // console.log(11111111111);

        if(this.tabNum == 3){
          // console.log('j经销商 长度 ',this.dealers);
          if(this.dealers>10||this.dealers==0 || this.dealers== undefined){

            // let pno = this.$store.getters.pno + 1;
            let pno = this.$store.getters.pno + 1;
            
            let params = this.clone(this.$store.getters.params);
            params.pageNumber = pno;

            console.log('yema页码',pno,params);

            this.$http.getAbs(params).then(res=>{
              if(!!res.status){
                // console.log('+++++++++得到 绝对量 数据 ++++++++',res.data);
                  this.$store.commit('setPno',pno);
                  let data = res.data.slice(3);

                  if(data.length<1){
                    this.finished = true;
                  }else{
                    this.finished = false;
                  }
                  // 把数据 放到 数据 仓库    其他 页面 都用  computed  去仓库 取   concat
                  for(let tmp of data){
                    this.list.push(tmp);
                  }
                  console.log('新数据 ----  ',data);

                  setTimeout(()=>{
                  //关闭  loading
                    this.loading = false;
                  },200);

                }else{
                  // 提示 
                  Toast.fail('绝对量数据加载失败');
                  this.loading = false;
                }
            })

          }else{
            this.loading = false;
          }
        }
      // },200);

    },
    //  克隆
    clone(obj){
      if(obj === null)return null
      if(Object.prototype.toString.call(obj) === '[object Array]'){
        var newArr = [];
        for(let tmp of obj){
          if(typeof tmp !== 'object'){
            newArr.push(tmp)
          }else{
            newArr.push(this.clone(tmp))
          }
        }
        return newArr;
      }
      var newObj = {};
      for(let key in obj){
        if(typeof obj[key] !== 'object'){
          newObj[key] = obj[key]
        }else{
          newObj[key] = this.clone(obj[key])
        }
      }
      return newObj
    },
    paramsChange(){
      this.finished = this.finished1;
    },
  },
  
  watch:{
    'params.time'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.region'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.provice'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.lable'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.seriesId'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.mark'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.dealerCode'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.pageNumber'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    dataType(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
  }




}
</script>

<style scoped>
  .bg_blue{
    background-color:#1E81D2;
  }
  .bg_gray{
    background-color:#eee;
  }
  
  img{
    width:18px;
  }
  .p_10{
    padding:10px;
  }
  .flex_row_start{
    justify-content: flex-start;
    
  }
  .w_33{
    width:33.333333%
  }


</style>
