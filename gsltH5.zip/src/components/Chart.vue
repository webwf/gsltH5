<template>
  <div>

    <van-row  class='text_c m_t_20'>
      <van-col span="8">
        <span class='color_item color1' ></span>
        <span>当日数据</span>
      </van-col>
      <van-col span="8">
        <span class='color_item color2'></span>
        <span>同日数据</span>
      </van-col>
      <van-col span="8">
        <span class='color_item color3'></span>
        <span>全月数据</span>
      </van-col>
    </van-row>

    <van-row >
      <!-- 左边的 图 -->
      <van-col span="16">
        <div class="echartBox " id='echart'>

        </div>
      </van-col>
      <!-- 右边 -->
      <van-col span="8">
        <div class='right_box p_r_3 '>
          <div>
            <div class='f_11 m_t_10'>{{lastYearMonth}}</div>
            <div class='right_item m_t_10 f_11'>
              <div :style="{color:(compare == 1)?'#1EEB23':(compare == -1)?'#FF4242':''}">{{compareNum}}%</div>
              <div>
                <img :src="imgUrl1" alt="" class='img'>  
              </div>
              <div class='f_11'>同比</div>
            </div>
            <div class='f_11 text_r m_t_10'>{{thisMonth}}</div>
          </div>

          <div style='width:80%;margin:.2rem auto;height:0;border:1px solid #eee' ></div>
          
          <div>
            <div class='f_11  text_r'>{{thisMonth}}</div>
            <div class='right_item m_t_10 f_11'>
              <div :style="{color:(sequential == 1)?'#1EEB23':(sequential == -1)?'#FF4242':''}">{{sequentialNum}}%</div>
              <div>
                <img :src="imgUrl2" alt="" class='img'>  
              </div>
              <div class='f_11'>环比</div>
            </div>
            <div class='f_11  m_t_10'>{{lastMonth}}</div>
          </div>


          <div class='f_11 m_t_20' style='color:#aaa'>(同日累计)</div>

        </div>
      </van-col>

    </van-row>
    

  </div>
</template>

<script>

// sequential
export default {
  name: 'Chart',  // 图表 
  props:['tabNum','userLevel'],
  data () {
    return {
      //  当前 选择的月份 是否 为  当前真实月份
      isNow:true,

      compare:0,   //  同比  -1  0  1
      sequential:0,   //环比
      compareNum:'0.00',
      sequentialNum:'0.00',
      lastMonth:'',
      thisMonth:'',
      lastYearMonth:'',

      src :[],
      option:{
        legend: {},
        tooltip: {},
        grid: [{bottom: '10%',left:'2%',right:'1%',top:'20%'}],
        dataset: {
            source: 
            [
                // ['product', '当日数据', '同日数据', '全月数据'],
                ['',,,],
                ['',,,],
                ['',,,]
                // ['2018-06',12,144,568],
                // ['2019-05',35,231,561],
                // ['2019-06',25,343,468]
            ]
        },
        xAxis: { 
          type: 'category',
          axisLine: {show:false},
          axisTick: { show: false },
        },
        yAxis: {show:false},
        series: [
            {type: 'bar',
              itemStyle:{  
                normal:{
                  color:'#FFB10D',
                  label: {
                    show: true, //开启显示
                    position: 'top', //在上方显示
                    offset:[0,6],
                    textStyle: { //数值样式
                      color: 'black',
                      fontSize: 10
                    }
                  }
                }  
              }
            },
            {type: 'bar',
              itemStyle:{  
                normal:{
                  color:'#20D2D0',
                  label: {
                    show: true, //开启显示
                    position: 'top', //在上方显示
                    offset:[0,-4],
                    textStyle: { //数值样式
                      color: 'black',
                      fontSize: 10
                    }
                  }
                }  
              }
            },
            {type: 'bar',
              itemStyle:{  
                normal:{
                  color:'#2082D2',
                  label: {
                    show: true, //开启显示
                    position: 'top', //在上方显示
                    offset:[0,-14],
                    textStyle: { //数值样式
                      color: 'black',
                      fontSize: 10
                    }
                  }
                }  
              }
            },
        ]
      },

    }
  },
  computed:{
    imgUrl1(){
      return require((this.compare == 1)?'../assets/up.png':(this.compare == -1)?'../assets/down.png':'../assets/same.png')
    },
    imgUrl2(){
      return require((this.sequential == 1)?'../assets/up.png':(this.sequential == -1)?'../assets/down.png':'../assets/same.png')
    },
    data1(){
      return this.$store.getters.compareData
    },
    month(){
      return this.$store.getters.params.time
    }
  },
  watch:{
    data1(){
      this.src = [
        // ['product', '当日数据', '同日数据', '全月数据'],
          [this.data1.LASTYEAR, Number(this.data1.LASTYEAR_NUM), Number(this.data1.LASTYEAR_SAMEDAY_NUM), Number(this.data1.LASTYEAR_NUM)],
          [this.data1.LASTMONTH, Number(this.data1.LASTMOTHDAY_NUM), Number(this.data1.LASTMOTH_SAMEDAY_NUM), Number(this.data1.LASTMOTH_NUM)],
          [this.data1.CURRENDAY, Number(this.data1.CURRENDAY_NUM), Number(this.data1.CURRENDAY_SAMEDAY_NUM), (this.isNow ? '' : Number(this.data1.CURRENMONTH_NUM))],
        ]
      // console.log('111111比较数据 改变了',this.src);
      this.option.dataset.source = this.src;
      this.hua();

      // 计算 同比 环比的 结果
      this.lastMonth = this.data1.LASTMONTH;
      this.thisMonth = this.data1.CURRENDAY;
      this.lastYearMonth = this.data1.LASTYEAR;
      if(1){

      }

      this.compare = Number(this.data1.CURRENDAY_SAMEDAY_NUM) > Number(this.data1.LASTYEAR_NUM) ? 1 : Number(this.data1.CURRENDAY_SAMEDAY_NUM) < Number(this.data1.LASTYEAR_NUM) ? -1 : 0 ;   //  同比  -1  0  1
      this.sequential = Number(this.data1.CURRENDAY_SAMEDAY_NUM) > Number(this.data1.LASTMOTH_SAMEDAY_NUM) ? 1 : Number(this.data1.CURRENDAY_SAMEDAY_NUM) < Number(this.data1.LASTMOTH_SAMEDAY_NUM) ? -1 : 0 ;   //  环比  -1  0  1
      //   同比
      if(this.data1.LASTYEAR_NUM != 0 ){
        if( this.compare == 0 ){
          this.compareNum = '0.00';
        }else{
          this.compareNum = (Math.abs( Number( this.data1.CURRENDAY_SAMEDAY_NUM) - Number( this.data1.LASTYEAR_NUM ))/Number(this.data1.LASTYEAR_NUM)*100).toFixed(2)
        }
      }else{
        if( this.compare == 0 ){
          this.compareNum = '0.00';
        }else{
          this.compareNum = '100.00'
        }
      }

      //  ///   环比
      if(this.data1.LASTMOTH_SAMEDAY_NUM != 0 ){
        if( this.sequential == 0 ){
          this.sequentialNum = '0.00';
        }else{
          this.sequentialNum = (Math.abs( Number( this.data1.CURRENDAY_SAMEDAY_NUM) - Number( this.data1.LASTMOTH_SAMEDAY_NUM ))/Number(this.data1.LASTMOTH_SAMEDAY_NUM)*100).toFixed(2)
        }
      }else{
        if( this.sequential == 0 ){
          this.sequentialNum = '0.00';
        }else{
          this.sequentialNum = '100.00';
        }
      }

      // 同比：    
      // (.CURRENDAY_SAMEDAY_NUM-.LASTYEAR_NUM)/.LASTYEAR_NUM*100:0;
      // 环比：    
      // (.CURRENDAY_SAMEDAY_NUM-.LASTMOTH_SAMEDAY_NUM)/.LASTMOTH_SAMEDAY_NUM*100:0;
            // 环比：    (compareModel.CURRENDAY_SAMEDAY_NUM-compareModel.LASTMOTH_SAMEDAY_NUM)
            // ?(compareModel.CURRENDAY_SAMEDAY_NUM-compareModel.LASTMOTH_SAMEDAY_NUM)/compareModel.LASTMOTH_SAMEDAY_NUM*100:0;

    },
    //  监听  月份 的改变  控制 图表 最后 一列 显示与否
    month(){
      let y = new Date().getFullYear();
      let m = new Date().getMonth()+1;
      m = m<10 == 1 ? '0'+ m : m;
      let monthNow = y+'-'+m;
      console.log('打印 当前 月份 和选择 月份  +++ ',monthNow,this.month)

      this.isNow = monthNow == this.month ? true :false
    }

  },
  methods:{
    hua(){
      var html = document.documentElement;
      var width = html.getBoundingClientRect().width;
      html.style.fontSize = width / 7.5 + 'px';//至于除数15可自行设置
      // console.log(width);
      // console.log(html.style.fontSize);
      this.height = width*5;
      // console.log(this.height)
      // this.data = this.sdata;
      var myEchart = document.getElementById('echart');
      myEchart.style.width = '100%';
      myEchart.style.height = '4rem';
      var myChart = this.$echarts.init(myEchart);

      myChart.setOption(this.option);
    }
    
  },
  created(){

    this.m = new Date().getMonth + 1;


  },
  mounted(){
    this.hua();
  
  },
  updated(){

  },

}
</script>

<style scoped>
  .container .echartBox{
    width:100%;
    height:3.5rem;
  }
  .color_item{
    display: inline-block;
    width:12px;
    height:12px;
    border-radius:3px;
  }
  .color1{background-color: #FFB10D}
  .color2{background-color: #20D2D0}
  .color3{background-color: #2082D2}
  .right_box{  padding:.8rem  0.2rem .3rem 0; }
  .img{  width:.45rem;  }
  .right_item{
    display:flex;
    justify-content: space-between;
    align-items: center;
  }
  
</style>
