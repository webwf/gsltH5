<template>
  <div class='p_10'>

    <div class='m_t_20 flex_row  text_c'>
      <div v-for='(item,i) of totalList1' :key='i'> 
        <div>
          <div style='margin:0 auto;' class='square' :style='{backgroundColor:item.color}'></div>
        </div>
        <div class='m_t_10'>{{item.name}}</div>
      </div>
    </div>


    <div class='m_t_20' v-if='totalData1!=undefined' style='margin-left:9%'>
      <div class='f_16 strong text_l'>{{this.totalData1['LABLENAME']}}({{this.totalData1['FENMU']}})</div>
      <div class='my_flex_box'>
        <div class='m_t_4  f_11 car_box text_l' v-for='(item,i) of totalList1' :key='i' >
          <span>{{item.name}}:</span>
          <span>{{item.count}}</span>
          <span>({{item.rate}}%)</span>
        </div>
      </div>
    </div>

<!-- 区域 合计 -->
    <div class='m_t_20' v-if='totalData2!=undefined && (userLevel!=1 && tabNum != 1)' style='margin-left:9%'>
      <div class='f_16 strong text_l'>{{this.totalData2['LABLENAME']}}({{this.totalData2['FENMU']}})</div>
      <div class='my_flex_box'>
        <div class='m_t_4  f_11 car_box text_l' v-for='(item,i) of totalList2' :key='i' >
          <span>{{item.name}}:</span>
          <span>{{item.count}}</span>
          <span>({{item.rate}}%)</span>
        </div>
      </div>
    </div>
<!-- 店  合计 -->
    <div class='m_t_20' v-if='totalData3!=undefined && (userLevel!=1 && tabNum==3 && dealers==1)' style='margin-left:9%'>
      <div class='f_16 strong text_l'>{{this.totalData3['LABLENAME']}}({{this.totalData3['FENMU']}})</div>
      <div class='my_flex_box'>
        <div class='m_t_4  f_11 car_box text_l' v-for='(item,i) of totalList3' :key='i' >
          <span>{{item.name}}:</span>
          <span>{{item.count}}</span>
          <span>({{item.rate}}%)</span>
        </div>
      </div>
    </div>


    <div class='m_t_40' v-if='dataList.length!=0'>
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
        v-if='tabNum==3'
      >

        <div class='flex_row m_t_20 flex_row_start' v-for='(item,i) of dataList' :key='i'>
          <!-- 左边 名次 -->
          <div class='w_7'>
            <div v-if='i==0'>
              <img  alt="冠军" src="../assets/jp1.png" >
            </div>
            <div v-else-if='i==1'>
              <img alt="亚军" src="../assets/jp2.png" >
            </div>
            <div v-else-if='i==2'>
              <img alt="季军" src="../assets/jp3.png" >
            </div>
            <div v-else>
              <span>{{i+1}}</span>
            </div>
          </div>

          <!-- 右边 -->

          <div class='w_87'>
            <div class='f_15 strong text_l'>{{item.LABLENAME}}({{item.FENZI}}、{{item.FENZI==0? '0.00' : ((item.FENZI/item.FENMU)*100).toFixed(2)}}%)</div>
            <div class='my_flex_box'>
              <div class='m_t_4  f_11 car_box'>
                <span>奕歌:</span>
                <span>{{item.NS_NUM}}</span>
                <span>({{item.NS_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>欧蓝德:</span>
                <span>{{item.OLD_NUM}}</span>
                <span>({{item.OLD_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>劲炫:</span>
                <span>{{item.JX_NUM}}</span>
                <span>({{item.JX_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>新能源:</span>
                <span>{{item.XNY_NUM}}</span>
                <span>({{item.XNY_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>进口车:</span>
                <span>{{item.JKC_NUM}}</span>
                <span>({{item.JKC_RATE.toFixed(2)}}%)</span>
              </div>
            </div>

            <div class="bg_gray h_14">
              <div class='h_14 flex_float m_t_20' :style="{width:(item.FENZI/item.FENMU)*100+'%'}">
                <div class='h_14' style='background-color:#FF534F' :style="{width:item.NS_RATE+'%'}"> 
                  <span v-if='(item.FENZI/item.FENMU)*item.NS_RATE>=20'>{{item.NS_RATE.toFixed(2)}}%</span>
                </div>
                <div class='h_14' style='background-color:#E59F59' :style="{width:item.OLD_RATE+'%'}"> 
                  <span v-if='(item.FENZI/item.FENMU)*item.OLD_RATE>=20'>{{item.OLD_RATE.toFixed(2)}}%</span>
                </div>
                <div class='h_14' style='background-color:#4896FF' :style="{width:item.JX_RATE+'%'}"> 
                  <span v-if='(item.FENZI/item.FENMU)*item.JX_RATE>=20'>{{item.JX_RATE.toFixed(2)}}%</span>
                </div>
                <div class='h_14' style='background-color:#88CF33' :style="{width:item.XNY_RATE+'%'}"> </div>
                <div class='h_14' style='background-color:#1CCDE7' :style="{width:item.JKC_RATE+'%'}"> </div>
              </div>
            </div>

          </div>
        </div>
      </van-list>

<!-- 否则  不需要 上拉  加载 更多 -->
      <div v-else>
        <div class='flex_row m_t_20 flex_row_start' v-for='(item,i) of dataList' :key='i'>
          <!-- 左边 名次 -->
          <div class='w_7'>
            <div v-if='i==0'>
              <img  alt="冠军" src="../assets/jp1.png" >
            </div>
            <div v-else-if='i==1'>
              <img alt="亚军" src="../assets/jp2.png" >
            </div>
            <div v-else-if='i==2'>
              <img alt="季军" src="../assets/jp3.png" >
            </div>
            <div v-else>
              <span>{{i+1}}</span>
            </div>
          </div>

          <!-- 右边 -->

          <div class='w_87'>
            <div class='f_15 strong text_l'>{{item.LABLENAME}}({{item.FENZI}}、{{item.FENZI==0? '0.00' : ((item.FENZI/item.FENMU)*100).toFixed(2)}}%)</div>
            <div class='my_flex_box'>
              <div class='m_t_4  f_11 car_box'>
                <span>奕歌:</span>
                <span>{{item.NS_NUM}}</span>
                <span>({{item.NS_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>欧蓝德:</span>
                <span>{{item.OLD_NUM}}</span>
                <span>({{item.OLD_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>劲炫:</span>
                <span>{{item.JX_NUM}}</span>
                <span>({{item.JX_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>新能源:</span>
                <span>{{item.XNY_NUM}}</span>
                <span>({{item.XNY_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>进口车:</span>
                <span>{{item.JKC_NUM}}</span>
                <span>({{item.JKC_RATE.toFixed(2)}}%)</span>
              </div>
            </div>

            <div class="bg_gray h_14">
              <div class='h_14 flex_float m_t_20' :style="{width:(item.FENZI/item.FENMU)*100+'%'}">
                <div class='h_14' style='background-color:#FF534F' :style="{width:item.NS_RATE+'%'}"> 
                  <span v-if='(item.FENZI/item.FENMU)*item.NS_RATE>=20'>{{item.NS_RATE.toFixed(2)}}%</span>
                </div>
                <div class='h_14' style='background-color:#E59F59' :style="{width:item.OLD_RATE+'%'}"> 
                  <span v-if='(item.FENZI/item.FENMU)*item.OLD_RATE>=20'>{{item.OLD_RATE.toFixed(2)}}%</span>
                </div>
                <div class='h_14' style='background-color:#4896FF' :style="{width:item.JX_RATE+'%'}"> 
                  <span v-if='(item.FENZI/item.FENMU)*item.JX_RATE>=20'>{{item.JX_RATE.toFixed(2)}}%</span>
                </div>
                <div class='h_14' style='background-color:#88CF33' :style="{width:item.XNY_RATE+'%'}"> </div>
                <div class='h_14' style='background-color:#1CCDE7' :style="{width:item.JKC_RATE+'%'}"> </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>




  </div>
</template>

<script>


export default {
  name: 'Cars',  //  车系 
  props:['tabNum','userLevel','finished2'],
  data () {
    return {
      //   总计 列表   数据 初始化
      totalList1:[
        {color:'#FF534F',name:'奕歌', count:0, rate :0},
        {color:'#E59F59',name:'欧蓝德', count:0, rate :0},
        {color:'#4896FF',name:'劲炫', count:0, rate :0},
        {color:'#88CF33',name:'新能源',count:0, rate :0},
        {color:'#1CCDE7',name:'进口车', count:0, rate :0},
      ],
      totalList2:[
        {color:'#FF534F',name:'奕歌', count:0, rate :0},
        {color:'#E59F59',name:'欧蓝德', count:0, rate :0},
        {color:'#4896FF',name:'劲炫', count:0, rate :0},
        {color:'#88CF33',name:'新能源',count:0, rate :0},
        {color:'#1CCDE7',name:'进口车', count:0, rate :0},
      ],
      totalList3:[
        {color:'#FF534F',name:'奕歌', count:0, rate :0},
        {color:'#E59F59',name:'欧蓝德', count:0, rate :0},
        {color:'#4896FF',name:'劲炫', count:0, rate :0},
        {color:'#88CF33',name:'新能源',count:0, rate :0},
        {color:'#1CCDE7',name:'进口车', count:0, rate :0},
      ],
      // totalData:{}, // 总数据
      // dataList:[],  // 数据列表

      loading: false,
      finished: false,
    }
  },
  methods:{
    onLoad() {
      // 异步更新数据
      // 加载状态结束
      if(this.tabNum == 3){

        if(this.dealers>10||this.dealers==0 || this.dealers== undefined){
          let pno = this.$store.getters.pno + 1;
          // console.log(this.$store.getters.pno);
          this.$store.commit('setPno',pno);
          let params = this.clone(this.$store.getters.params);
          // let params = this.$emit('clone',this.$store.getters.params);
          params.pageNumber = pno;

          console.log('yema页码',pno);

          this.$http.getSeries(params).then(res=>{
            if(!!res.status){
              // console.log('+++++ 分页 车系 数据 ++++++++',res.data);

                let data = res.data.slice(3);
                if(data.length<1){
                  this.finished = true;
                }else{
                  this.finished = false;
                }
                // 把数据 放到 数据 仓库    其他 页面 都用  computed  去仓库 取   concat
                for(let tmp of data){
                  this.dataList.push(tmp);
                }
                console.log('新 车系 数据 ----  ',data);

                setTimeout(()=>{
                //关闭  loading
                  this.loading = false;
                },200);

              }else{
                // 提示 
                Toast.fail('车系数据加载失败');
                this.loading = false;
              }
          })


        }else{
          this.loading = false;
        }
      }

    },
     // 克隆
    clone(obj){
      // console.log('调用 父组件的 clone 方法',obj);
      if(obj === null)return null
      if(Object.prototype.toString.call(obj) === '[object Array]'){
        var newArr = [];
        for(let tmp of obj){
          if(typeof tmp !== 'object'){
            newArr.push(tmp)
          }else{
            newArr.push(this.clone(tmp))
          }
        }
        return newArr;
      }
      var newObj = {};
      for(let key in obj){
        if(typeof obj[key] !== 'object'){
          newObj[key] = obj[key]
        }else{
          newObj[key] = this.clone(obj[key])
        }
      }
      return newObj
    },
    paramsChange(){
      this.finished = this.finished2;
      // console.log('params  变化了',this.finished);
    },

  },
  computed:{
    totalData1(){
      return this.$store.getters.series[0]
    },
    totalData2(){
      return this.$store.getters.series[1]
    },
    totalData3(){
      return this.$store.getters.series[2]
    },
    dataList(){
      return this.$store.getters.series.slice(3)
    },
    params(){
      return this.$store.getters.params;
    },
    dealers(){
      if(this.params.dealerCode==''){
        console.log('所选 经销商 长度',0);
        return 0
      }else{
        console.log('所选 经销商 长度',this.params.dealerCode.split(',').length);
        return this.params.dealerCode.split(',').length
      }

    },

  },
  watch:{
    totalData1(){
      this.totalList1[0].count = this.totalData1['NS_NUM']; 
      this.totalList1[0].rate = this.totalData1['NS_RATE'];
      this.totalList1[1].count = this.totalData1['OLD_NUM'];
      this.totalList1[1].rate = this.totalData1['OLD_RATE'];
      this.totalList1[2].count = this.totalData1['JX_NUM'];
      this.totalList1[2].rate = this.totalData1['JX_RATE'];
      this.totalList1[3].count = this.totalData1['XNY_NUM'];
      this.totalList1[3].rate = this.totalData1['XNY_RATE'];
      this.totalList1[4].count = this.totalData1['JKC_NUM'];
      this.totalList1[4].rate = this.totalData1['JKC_RATE'];
    },
    totalData2(){
      this.totalList2[0].count = this.totalData2['NS_NUM']; 
      this.totalList2[0].rate = this.totalData2['NS_RATE'];
      this.totalList2[1].count = this.totalData2['OLD_NUM'];
      this.totalList2[1].rate = this.totalData2['OLD_RATE'];
      this.totalList2[2].count = this.totalData2['JX_NUM'];
      this.totalList2[2].rate = this.totalData2['JX_RATE'];
      this.totalList2[3].count = this.totalData2['XNY_NUM'];
      this.totalList2[3].rate = this.totalData2['XNY_RATE'];
      this.totalList2[4].count = this.totalData2['JKC_NUM'];
      this.totalList2[4].rate = this.totalData2['JKC_RATE'];
    },
    totalData3(){
      this.totalList3[0].count = this.totalData3['NS_NUM']; 
      this.totalList3[0].rate = this.totalData3['NS_RATE'];
      this.totalList3[1].count = this.totalData3['OLD_NUM'];
      this.totalList3[1].rate = this.totalData3['OLD_RATE'];
      this.totalList3[2].count = this.totalData3['JX_NUM'];
      this.totalList3[2].rate = this.totalData3['JX_RATE'];
      this.totalList3[3].count = this.totalData3['XNY_NUM'];
      this.totalList3[3].rate = this.totalData3['XNY_RATE'];
      this.totalList3[4].count = this.totalData3['JKC_NUM'];
      this.totalList3[4].rate = this.totalData3['JKC_RATE'];
    },
    'params.time'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.region'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.provice'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.lable'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.seriesId'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.mark'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.dealerCode'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.pageNumber'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    dataType(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
  },
  created(){
    // this.carClick()
  }
}
// FF534F   E59F59  4896FF   88CF33   1CCDE7
</script>

<style scoped>
  .text_l{text-align: left}
  .p_10{
    padding:10px;
  }
  .square{
    width:15px;
    height:15px;
    border-radius:3px;
    background:#FF534F
  }
  .w_7{width:7%;margin-right:2%}
  .my_flex_box{
    display:flex;
    flex-wrap: wrap;
    text-align:left;
  }
  .car_box{
    width:50%;
  }
  .car_box1{
    width:33.333333%;
  }
  .w_87{
    width:87%
  }
  img{
    width:18px;
  }
  .h_14{
    height:14px;
    line-height:14px;
  }
  .flex_float{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    
  }
  .flex_row_start{
    justify-content: flex-start;
    
  }
  .bg_gray{
    background-color: #eee
  }

</style>
