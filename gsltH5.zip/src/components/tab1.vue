<template>
  <div class="container">
    <van-tabs v-model="active" swipeable animated  :swipe-threshold='num'  :ellipsis='isEllipsis'  @change='changeTabs'>
      <van-tab v-for="i in 7" :title="'选项发生大声大声道 ' + i" :key='i'>
        
        <div style='height:400px;background-color:#ccc'>
          
          内容 {{ i }}
        </div>
      </van-tab>
      <van-tab title="选项发生大声大">
        <div style='height:400px;background-color:#aaa'>
          内容 
        </div>
      </van-tab>
      <van-tab title="选项发">
        <div style='height:400px;background-color:#aaa'>
          内容 
        </div>
      </van-tab>
      <van-tab title="选项发生">
        <div style='height:400px;background-color:#999'>
          内容 
        </div>
      </van-tab>
    </van-tabs>
    

  </div>
</template>

<script>

import Vue from 'vue';

import { Tab, Tabs, Row, Col ,Toast ,List } from 'vant';
Vue.use(Tab).use(Tabs).use(Row).use(Col).use(Toast).use(List);



export default {
  name: 'Tab1',  // 统计表
  data () {
    return {
      active:0,
      num:3,
      isEllipsis:false,


    }
  },
  computed:{


  },
  watch:{



  },
  created(){
    
  },
  mounted(){
    

  },

  methods:{
    changeTabs(name,title){
      console.log('改变了 tabs ',name,title);


      
    },




    //  获取 比较 数据

    


  }
}
</script>

<style >





</style>
