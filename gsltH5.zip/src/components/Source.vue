<template>
  <div class='p_10'>

    <div class='m_t_20 flex_row text_c f_11' v-if='totalList1!=undefined'>
      <div v-for='(item,i) of totalList1' :key='i'> 
        <div>
          <div style='margin:0 auto;' class='square' :style='{backgroundColor:item.color}'></div>
        </div>
        <div class='m_t_10'>{{item.name}}</div>
      </div>
    </div>


    <div class='m_t_20 ' v-if='totalData1!=undefined' style='margin-left:9%'>
      <div class='f_16 strong text_l'>{{this.totalData1['LABLENAME']}}({{this.totalData1['FENMU']}})</div>
      <div class='my_flex_box m_t_10'>
        <div class='m_t_4  f_11 car_box text_l' v-for='(item,i) of totalList1' :key='i' >
          <span>{{item.name}}:</span>
          <span>{{item.count}}</span>
          <span>({{(item.rate).toFixed(2)}}%)</span>
        </div>
      </div>
    </div>

    <div class='m_t_20 ' v-if='totalData2!=undefined && (userLevel!=1 && tabNum != 1)' style='margin-left:9%'>
      <div class='f_16 strong text_l'>{{this.totalData2['LABLENAME']}}({{this.totalData2['FENMU']}})</div>
      <div class='my_flex_box m_t_10'>
        <div class='m_t_4  f_11 car_box text_l' v-for='(item,i) of totalList2' :key='i' >
          <span>{{item.name}}:</span>
          <span>{{item.count}}</span>
          <span>({{(item.rate).toFixed(2)}}%)</span>
        </div>
      </div>
    </div>

    <div class='m_t_20 ' v-if='totalData3!=undefined && (userLevel!=1 && tabNum==3 && dealers==1)' style='margin-left:9%'>
      <div class='f_16 strong text_l'>{{this.totalData3['LABLENAME']}}({{this.totalData3['FENMU']}})</div>
      <div class='my_flex_box m_t_10'>
        <div class='m_t_4  f_11 car_box text_l' v-for='(item,i) of totalList3' :key='i' >
          <span>{{item.name}}:</span>
          <span>{{item.count}}</span>
          <span>({{(item.rate).toFixed(2)}}%)</span>
        </div>
      </div>
    </div>


    <div class='m_t_40' v-if='dataList.length!=0 && totalList1 != undefined'>
      <van-list
        v-model="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
        v-if='tabNum==3'
      >

        <div class='flex_row flex_float m_t_20' v-for='(item,i) of dataList' :key='i'>
          <!-- 左边 名次 -->
          <div class='w_7'>
            <div v-if='i==0'>
              <img  alt="冠军" src="../assets/jp1.png" >
            </div>
            <div v-else-if='i==1'>
              <img alt="亚军" src="../assets/jp2.png" >
            </div>
            <div v-else-if='i==2'>
              <img alt="季军" src="../assets/jp3.png" >
            </div>
            <div v-else>
              <span>{{i+1}}</span>
            </div>
          </div>

          <!-- 右边 -->

          <div class='w_87'>
            <div class='f_15 strong text_l'>{{item.LABLENAME}}({{item.FENZI}}、{{item.RATE==0? '0.00' : item.RATE.toFixed(2)}}%)</div>
            <div class='my_flex_box'>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[0].name}}:</span>
                <span>{{item.ZRDD_NUM}}</span>
                <span>({{item.ZRDD_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[1].name}}:</span>
                <span>{{item.ZDJK_NUM}}</span>
                <span>({{item.ZDJK_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[2].name}}:</span>
                <span>{{item.EW_NUM}}</span>
                <span>({{item.EW_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[3].name}}:</span>
                <span>{{item.TJ_NUM}}</span>
                <span>({{item.TJ_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[4].name}}:</span>
                <span>{{item.DHHR_NUM}}</span>
                <span>({{item.DHHR_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[5].name}}:</span>
                <span>{{item.WL_NUM}}</span>
                <span>({{item.WL_RATE.toFixed(2)}}%)</span>
              </div>
            </div>


            <div class='h_14 bg_gray'>
              <div class='h_14 flex_float m_t_20' :style="{width:item.RATE +'%'}">
                <div class='h_14' style='background-color:#FF534F' :style="{width:item.ZRDD_RATE+'%'}"> 
                  <!-- <span v-if='item.WL_RATE>=20'>{{item.WL_RATE.toFixed(2)}}%</span> -->
                </div>
                <div class='h_14' style='background-color:#E59F59' :style="{width:item.ZDJK_RATE+'%'}"> 
                  <!-- <span v-if='item.ZRDD_RATE>=20'>{{item.ZRDD_RATE.toFixed(2)}}%</span> -->
                </div>
                <div class='h_14' style='background-color:#4896FF' :style="{width:item.EW_RATE+'%'}"> 
                  <!-- <span v-if='item.ZDJK_RATE>=20'>{{item.ZDJK_RATE.toFixed(2)}}%</span> -->
                </div>
                <div class='h_14' style='background-color:#88CF33' :style="{width:item.TJ_RATE+'%'}"> </div>
                <div class='h_14' style='background-color:#1CCDE7' :style="{width:item.DHHR_RATE+'%'}"> </div>
                <div class='h_14' style='background-color:#AAAAAA' :style="{width:item.WL_NUM+'%'}"> </div>
              </div>

            </div>

          </div>
        </div>
      </van-list>


      <div v-else>
                <div class='flex_row flex_float m_t_20' v-for='(item,i) of dataList' :key='i'>
          <!-- 左边 名次 -->
          <div class='w_7'>
            <div v-if='i==0'>
              <img  alt="冠军" src="../assets/jp1.png" >
            </div>
            <div v-else-if='i==1'>
              <img alt="亚军" src="../assets/jp2.png" >
            </div>
            <div v-else-if='i==2'>
              <img alt="季军" src="../assets/jp3.png" >
            </div>
            <div v-else>
              <span>{{i+1}}</span>
            </div>
          </div>

          <!-- 右边 -->

          <div class='w_87'>
            <div class='f_15 strong text_l'>{{item.LABLENAME}}({{item.FENZI}}、{{item.RATE==0? '0.00' : item.RATE.toFixed(2)}}%)</div>
            <div class='my_flex_box'>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[0].name}}:</span>
                <span>{{item.ZRDD_NUM}}</span>
                <span>({{item.ZRDD_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[1].name}}:</span>
                <span>{{item.ZDJK_NUM}}</span>
                <span>({{item.ZDJK_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[2].name}}:</span>
                <span>{{item.EW_NUM}}</span>
                <span>({{item.EW_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[3].name}}:</span>
                <span>{{item.TJ_NUM}}</span>
                <span>({{item.TJ_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[4].name}}:</span>
                <span>{{item.DHHR_NUM}}</span>
                <span>({{item.DHHR_RATE.toFixed(2)}}%)</span>
              </div>
              <div class='m_t_4  f_11 car_box'>
                <span>{{totalList1[5].name}}:</span>
                <span>{{item.WL_NUM}}</span>
                <span>({{item.WL_RATE.toFixed(2)}}%)</span>
              </div>
            </div>


            <div class='h_14 bg_gray'>
              <div class='h_14 flex_float m_t_20' :style="{width:item.RATE +'%'}">
                <div class='h_14' style='background-color:#FF534F' :style="{width:item.ZRDD_RATE+'%'}"> 
                  <span v-if='item.WL_RATE>=20'>{{item.WL_RATE.toFixed(2)}}%</span>
                </div>
                <div class='h_14' style='background-color:#E59F59' :style="{width:item.ZDJK_RATE+'%'}"> 
                  <!-- <span v-if='item.ZRDD_RATE>=20'>{{item.ZRDD_RATE.toFixed(2)}}%</span> -->
                </div>
                <div class='h_14' style='background-color:#4896FF' :style="{width:item.EW_RATE+'%'}"> 
                  <!-- <span v-if='item.ZDJK_RATE>=20'>{{item.ZDJK_RATE.toFixed(2)}}%</span> -->
                </div>
                <div class='h_14' style='background-color:#88CF33' :style="{width:item.TJ_RATE+'%'}"> </div>
                <div class='h_14' style='background-color:#1CCDE7' :style="{width:item.DHHR_RATE+'%'}"> </div>
                <div class='h_14' style='background-color:#AAAAAA' :style="{width:item.WL_NUM+'%'}"> </div>
              </div>

            </div>

          </div>
        </div>
      </div>
    </div>




  </div>
</template>

<script>


export default {
  name: 'Source',  //  数据 来源
  props:['tabNum','userLevel','finished3'],
  data () {
    return {
      loading: false,
      finished: false,
      //   总计 列表   数据 初始化
      totalList1:[
        
      ],
      totalList2:[
        
      ],
      totalList3:[
        
      ],
      // totalData:{}, // 总数据
      // dataList:[],  // 数据列表
    }
  },

  methods:{

    onLoad() {
      // 异步更新数据
      // 加载状态结束
      if(this.tabNum == 3){
        if(this.dealers>10||this.dealers==0 || this.dealers== undefined){
          let pno = this.$store.getters.pno + 1;
          this.$store.commit('setPno',pno);
          let params = this.clone(this.$store.getters.params);
          // let params = this.$emit('clone',this.$store.getters.params);
          params.pageNumber = pno;

          console.log('yema页码',pno);

          this.$http.getSrc(params).then(res=>{
            if(!!res.status){
              // console.log('+++++++++得到 渠道 数据 ++++++++',res.data);

                let data = res.data.slice(3);
                if(data.length<1){
                  this.finished = true;
                }else{
                  this.finished = false;
                }
                // 把数据 放到 数据 仓库    其他 页面 都用  computed  去仓库 取   concat
                for(let tmp of data){
                  this.dataList.push(tmp);
                }
                console.log('新 渠道 数据 ----  ',data);

                setTimeout(()=>{
                //关闭  loading
                  this.loading = false;
                },200);

              }else{
                // 提示 
                Toast.fail('车系数据加载失败');
                this.loading = false;
              }
          })


        }else{
          this.loading = false;
        }
      }

    },
     // 克隆
    clone(obj){
      // console.log('调用 父组件的 clone 方法',obj);
      if(obj === null)return null
      if(Object.prototype.toString.call(obj) === '[object Array]'){
        var newArr = [];
        for(let tmp of obj){
          if(typeof tmp !== 'object'){
            newArr.push(tmp)
          }else{
            newArr.push(this.clone(tmp))
          }
        }
        return newArr;
      }
      var newObj = {};
      for(let key in obj){
        if(typeof obj[key] !== 'object'){
          newObj[key] = obj[key]
        }else{
          newObj[key] = this.clone(obj[key])
        }
      }
      return newObj
    },
    paramsChange(){
      this.finished = this.finished2;
    },

  },
  created(){
    let arr = this.$store.getters.lableList;
    let newArr = [];
    if(arr.length!=0){
      for(var tmp of arr){
        let obj = {};
        obj['name'] = tmp.CLUE_NAME;
        obj['count'] = 0;
        obj['rate'] = 0;
        newArr.push(obj);
      }
      newArr[0].color = '#FF534F';
      newArr[1].color = '#E59F59';
      newArr[2].color = '#4896FF';
      newArr[3].color = '#88CF33';
      newArr[4].color = '#1CCDE7';
      newArr[5].color = '#AAAAAA';

      // this.totalList1 = this.$emit('clone',newArr);
      // this.totalList2 = this.$emit('clone',newArr);
      // this.totalList3 = this.$emit('clone',newArr);

      this.totalList1 = this.clone(newArr);
      this.totalList2 = this.clone(newArr);
      this.totalList3 = this.clone(newArr);
      // this.$emit('clone',this.$store.getters.params);
      console.log('三个列表 ---- ',this.totalList1,this.totalList2,this.totalList3)
      console.log('三个列表 ---- ',newArr)
    }  


  },
  computed:{
    totalData1(){
      return this.$store.getters.source[0]
    },
    totalData2(){
      return this.$store.getters.source[1]
    },
    totalData3(){
      return this.$store.getters.source[2]
    },
    dataList(){
      return this.$store.getters.source.slice(3)
    },
    params(){
      return this.$store.getters.params;
    },
    dealers(){
      if(this.params.dealerCode==''){
        console.log('所选 经销商 长度',0);
        return 0
      }else{
        console.log('所选 经销商 长度',this.params.dealerCode.split(',').length);
        return this.params.dealerCode.split(',').length
      }

    },

  },
  watch:{
    'params.time'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.region'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.provice'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.lable'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.seriesId'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.mark'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.dealerCode'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    'params.pageNumber'(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    dataType(){
      this.$store.commit('setPno',1)
      this.paramsChange();
    },
    
    totalData1(){
      //  重新   组装   总计  的数据
      this.totalList1[0].count = this.totalData1['ZRDD_NUM']; 
      this.totalList1[0].rate = this.totalData1['ZRDD_RATE'];
      
      this.totalList1[1].count = this.totalData1['ZDJK_NUM'];
      this.totalList1[1].rate = this.totalData1['ZDJK_RATE'];

      this.totalList1[2].count = this.totalData1['EW_NUM'];
      this.totalList1[2].rate = this.totalData1['EW_RATE'];

      this.totalList1[3].count = this.totalData1['TJ_NUM'];
      this.totalList1[3].rate = this.totalData1['TJ_RATE'];

      this.totalList1[4].count = this.totalData1['DHHR_NUM'];
      this.totalList1[4].rate = this.totalData1['DHHR_RATE'];

      this.totalList1[5].count = this.totalData1['WL_NUM'];
      this.totalList1[5].rate = this.totalData1['WL_RATE'];

    },
    totalData2(){
      //  重新   组装   总计  的数据
      this.totalList2[0].count = this.totalData2['ZRDD_NUM']; 
      this.totalList2[0].rate = this.totalData2['ZRDD_RATE'];
      
      this.totalList2[1].count = this.totalData2['ZDJK_NUM'];
      this.totalList2[1].rate = this.totalData2['ZDJK_RATE'];

      this.totalList2[2].count = this.totalData2['EW_NUM'];
      this.totalList2[2].rate = this.totalData2['EW_RATE'];

      this.totalList2[3].count = this.totalData2['TJ_NUM'];
      this.totalList2[3].rate = this.totalData2['TJ_RATE'];

      this.totalList2[4].count = this.totalData2['DHHR_NUM'];
      this.totalList2[4].rate = this.totalData2['DHHR_RATE'];

      this.totalList2[5].count = this.totalData2['WL_NUM'];
      this.totalList2[5].rate = this.totalData2['WL_RATE'];

    },
    totalData1(){
      //  重新   组装   总计  的数据
      this.totalList3[0].count = this.totalData3['ZRDD_NUM']; 
      this.totalList3[0].rate = this.totalData3['ZRDD_RATE'];
      
      this.totalList3[1].count = this.totalData3['ZDJK_NUM'];
      this.totalList3[1].rate = this.totalData3['ZDJK_RATE'];

      this.totalList3[2].count = this.totalData3['EW_NUM'];
      this.totalList3[2].rate = this.totalData3['EW_RATE'];

      this.totalList3[3].count = this.totalData3['TJ_NUM'];
      this.totalList3[3].rate = this.totalData3['TJ_RATE'];

      this.totalList3[4].count = this.totalData3['DHHR_NUM'];
      this.totalList3[4].rate = this.totalData3['DHHR_RATE'];

      this.totalList3[5].count = this.totalData3['WL_NUM'];
      this.totalList3[5].rate = this.totalData3['WL_RATE'];

    },
  },

}
</script>

<style scoped>
  .text_l{text-align: left}
  .p_10{
    padding:10px;
  }
  .square{
    width:15px;
    height:15px;
    border-radius:3px;
    background:#FF534F
  }
  .w_7{width:7%;margin-right:2%}
  .my_flex_box{
    display:flex;
    flex-wrap: wrap;
    text-align:left;
  }
  .car_box{
    width:50%;
  }
  .car_box1{
    width:33.333333%;
  }
  .w_87{
    width:87%
  }
  img{
    width:18px;
  }
  .h_14{
    height:14px;
    line-height:14px;
  }
  .p_10{
    padding:10px;
  }
  .flex_float{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    
  }
  .bg_gray{
    background-color:#eee;
  }
</style>
