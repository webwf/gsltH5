<template>
  <div>
    <van-dropdown-menu style='width:100%;'>
    
      <van-dropdown-item :title="month" ref="item1">
        <van-row>
          <van-col span="24" class='scroll_box'>
            <div>
              <van-datetime-picker
                v-model="currentDate"
                type="year-month"
                :min-date="new Date('2018/10')"
                :max-date="new Date()"
                :formatter="formatter"
                title='请选择月份'
                @confirm = 'confirmDate'
                @cancel = 'onCancel(1)'
              />
            </div>
          </van-col>
        </van-row> 
      </van-dropdown-item>


      <van-dropdown-item :title="car" ref="item2">
        <div class='box'>
          <van-row  class='dropdown_box'>
            <van-col span='24' class='scroll_box pb_60' >
              <van-row >
                <van-col offset='2' span="8" class='m_t_6'><div class='text_l h_44 '>筛选车系</div></van-col>
                <van-col offset='4' span="8" class='m_t_6'><div class='h_44 bg_light ' :class='{selected:carSelectedAll}' @click='selectedAllToggle("car")'>全选</div></van-col>
              </van-row>

              <van-row>
                <van-col v-for="(item,i) of carList" :key='i' :offset='i&1?4:2' span="8" class='m_t_6 ' ><div class='text_c h_44 bg_light' :class='{selected:carList[i].selected}' @click='select(i,1)' >{{item.SERIES_NAME}}</div></van-col>
              </van-row>
                
            </van-col>
          </van-row>

          <van-row style='position:absolute;bottom:0;width:100%;'>
            <van-col span="12">
              <van-button block size='large' type="defalult" @click="onCancel(2)">取消</van-button>
            </van-col>
            <van-col span="12">
              <van-button block size='large' type="info" @click="onConfirmCar">确认</van-button>
            </van-col>
          </van-row>
        </div> 

      </van-dropdown-item>

      <van-dropdown-item :title="area" ref="item3">

        <van-row class='dropdown_box dropdown_box1'>

          <van-col span="8" class='scroll_box border_right'>
            <div class='scroll_box1'>
              <div class='pos_t'>区域</div>
              <div class='m_b_10 f_14 flex'   @click='selectedAllToggle("area")'><span class='item' :class="{select:selectAllArea}">全国</span></div>

              <div class='m_b_10 f_11 flex' v-for='(item,i) of areaList1' :key='i' @click='select(i,2,1)'><span class='item' :class="{select:item.selected}" >{{item.REGION}}</span></div>
            </div>
          </van-col>
          <van-col span="8" class='scroll_box border_right'>
            <div class='scroll_box1' v-if='tabNum!=1'>
              <div class='pos_t'>省份</div>

              <div class='m_b_10 f_11 flex' v-for='(item,i) of areaNowList2' :key='i' @click='select(i,2,2)'><span class='item' :class="{select:item.selected}" >{{item.PROVINCE}}</span></div>
            </div>
          </van-col>
          <van-col span="8" class='scroll_box '>
            <div class='scroll_box1' v-if='userLevel != 1 && tabNum==3'>
              <div class='pos_t'>经销商</div>

              <div class='m_b_10 f_11 flex' v-for='(item,i) of areaNowList3' :key='i' @click='select(i,2,3)'><span class='item' :class="{select:item.selected}" >{{item.DEALER_SHORTNAME}}</span></div>
            </div>
          </van-col>


        </van-row>


        <van-row style='position:absolute;bottom:0;width:100%;'>
          <van-col span="12">
            <van-button block size='large' type="defalult" @click="onCancel(3)">重置</van-button>
          </van-col>
          <van-col span="12">
            <van-button block size='large' type="info" @click="onConfirm(3)">确认</van-button>
          </van-col>
        </van-row>

      </van-dropdown-item> 


      <van-dropdown-item :title="lable" ref="item4">
        <div class='box'>
          <van-row  class='dropdown_box'>
            <van-col span='24' class='scroll_box pb_60'>
              <van-row >
                <van-col offset='2' span="8" class='m_t_6'><div class='text_l h_44 '>筛选渠道</div></van-col>
                <van-col offset='4' span="8" class='m_t_6'><div class='h_44 bg_light ' :class='{selected:sourceSelectedAll}' @click='selectedAllToggle("source")'>全选</div></van-col>
              </van-row>

              <van-row>
                <van-col v-for="(item,i) of sourceList" :key='i' :offset='i&1?4:2' span="8" class='m_t_6 ' ><div class='text_c h_44 bg_light' :class='{selected:sourceList[i].selected}' @click='select(i,3)' >{{item.CLUE_NAME}}</div></van-col>
              </van-row>
                
            </van-col>
          </van-row>

          <van-row style='position:absolute;bottom:0;width:100%;'>
            <van-col span="12">
              <van-button block size='large' type="defalult" @click="onCancel(4)">取消</van-button>
            </van-col>
            <van-col span="12">
              <van-button block size='large' type="info" @click="onConfirmSource">确认</van-button>
            </van-col>
          </van-row>
        </div> 

      </van-dropdown-item>

    </van-dropdown-menu>


  </div>
</template>

<script>

import Vue from 'vue';

import { DropdownMenu, DropdownItem } from 'vant';

Vue.use(DropdownMenu).use(DropdownItem);


export default {
  name: 'Select',  // 选择 
  component:{
    // Select
    // ,Provinces,Dealers
  },
  props:['tabNum','userLevel'],
  data () {
    return {
      currentDate: new Date(),
      //  月份数据
      month:'',
      // //  账号级别
      // userLevel:0,

      car:'车系',
      area:'区域',
      lable:'渠道分析',

      // 车型 列表
      carList:[],
      carSelectedAll:false,  //   车型  是否 全选 
      // 渠道 列表
      sourceList:[],
      sourceSelectedAll:false,  //   渠道 是否 全选 

      //   区域 数据
      areaIndex1: -1,
      selectAllArea:false,      //  区域 一级  全国  数据全选   则代表  一级  二级  全选
      areaList1:[],      //  区域 一级 数据列表

      areaIndex2: -1,
      areaList2:[],      //  区域 二级 数据列表
      areaNowList2:[],   //  当前 二级 数据

      areaIndex3: -1,
      areaList3:[],      //  区域 三级 数据列表
      areaNowList3:[],   //  当前 三级 数据
      // areaSelectedList333:[],   //  区域 三级 选中 的数据列表  因为 总数据可能 太大  遍历可能太慢  所以 暂存在这




    }
  },
  computed:{
    params(){
      return this.$store.getters.params
    },

  },

  created(){
    //  获取 账号级别
    // this.userLevel = this.$store.getters.params.appRole;
    // console.log('级别++++++++++++++',this.userLevel);

    //  获取  年-月  格式
    let y = new Date().getFullYear();
    let m = new Date().getMonth()+1;
    m = m<10 == 1 ? '0'+ m : m;
    this.month = y+'-'+m;
    this.$store.commit('setParams',{time:this.month});


    //  获取 车系 数据  【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】
    this.$http.getSeriesList(this.params).then(res=>{
      if(!!res.status){
        
        // let res1 = JSON.parse(JSON.stringify(res.data));
        // let res2 = JSON.parse(JSON.stringify(res.data));

        // this.$store.commit('setSeriesList',res1);
        
        this.carList = this.addSelected(res.data);
        // console.log('+++++++++得到  车系  列表 结果++++++++',this.carList);

      };
    })


    //  获取 渠道 数据   【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】
    this.$http.getLabelList(this.params).then(res=>{
      // console.log('----渠道  列表---------',res)
      if(res){
        res.push({CLUE_NAME: "网络",IS_ENABLE:10011001,ID:999});
        // let res1 = this.clone(res);
        // let res2 = this.clone(res);

        let res1 = JSON.parse(JSON.stringify(res));
        let res2 = JSON.parse(JSON.stringify(res));

        this.$store.commit('setLableList',res1);

        this.sourceList = this.addSelected(res2);
        // console.log('渠道 列表 +++',this.sourceList);
      };

    })

    // var resSrc = [
    //     {CLUE_NAME: "自然到店1",IS_ENABLE:10011001,ID:99129},
    //     {CLUE_NAME: "主动集客2",IS_ENABLE:10011001,ID:9949},
    //     {CLUE_NAME: "二网3",IS_ENABLE:10011001,ID:94399},
    //     {CLUE_NAME: "推荐4",IS_ENABLE:10011001,ID:9299},
    //     {CLUE_NAME: "电话呼入5",IS_ENABLE:10011001,ID:93199},
    //     {CLUE_NAME: "网络6",IS_ENABLE:10011001,ID:9299},
    //   ];
    // this.sourceList = this.addSelected(resSrc);


    // 获取 区域  一级  数据  【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】
    this.$http.getRegio(this.params).then(res=>{
      if(!!res.status){
        //  逐个 注入 selected 属性
        this.areaList1 = this.addSelected(res.data);
        // console.log('+++++++++ 区域 列表 ++++++++',this.areaList1);
      }

    })


    // 获取 区域  二级  数据 【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】【】
    this.$http.getProvince(this.params).then(res=>{
      if(!!res.status){
        //  逐个 注入 selected 属性
        this.areaList2 = this.addSelected(res.data);
        // console.log('++++++  省份 列表 +++++++',this.areaList2);
      }
    })
    



  },

  methods:{
    
    // 取消 关闭 相应 菜单  
    onCancel(i){
      this.closedDopdownMenu(i);

      //  取消  选择  车系  carList
      // if(i == 2){
      //   this.carList.map((item)=>item.selected = false)
      // }




    },
    // 确认  月份
    confirmDate(val){
      this.closedDopdownMenu(1);
      let year = val.getFullYear();
      let month = val.getMonth()+1;
      // console.log('选择了月份',year,'----',month);
      month = month<10 ? '0'+month : month;
      this.month = year + '-' + month;
      this.$store.commit('setParams',{time:this.month});

    },

    //  车系  区域   渠道    //  全选
    selectedAllToggle(val){
      if(val === 'car'){
        this.carSelectedAll = !this.carSelectedAll;
        this.selectAll(this.carList,this.carSelectedAll);
      }
      if(val === 'source'){
        this.sourceSelectedAll = !this.sourceSelectedAll;
        this.selectAll(this.sourceList,this.sourceSelectedAll);
      }
      if(val === 'area'){
        this.selectAllArea = !this.selectAllArea;
        // console.log(this.selectAllArea);
        this.selectAll(this.areaList1,this.selectAllArea);
        this.selectAll(this.areaList2,this.selectAllArea);
        //  三级列表  数据清零
        this.areaNowList3 = [];

        //  如果 全国 没被选中  false  二级  当前暂存 列表  清零
        if(!this.selectAllArea){
          this.areaNowList2 = [];
        }else{
          this.areaNowList2 = this.clone(this.areaList2); 
        }
      }
    },

    //  选择
    select(i,m,n){
      console.log(i,m,n);
      

      //  如果 m==1  代表 选 车系
      if(m == 1){
        this.carList[i].selected = !this.carList[i].selected;
        if(!this.carList[i].selected){
          this.carSelectedAll = false;
        }else{
          this.carSelectedAll = this.isSelectedAll(this.carList);
        }
      }

      //  如果 m==3  代表 选 渠道
      if(m == 3){
        this.sourceList[i].selected = !this.sourceList[i].selected;
        // this.sourceList[i].selected = true;
        console.log(this.sourceList);
        
        if(!this.sourceList[i].selected){
          this.sourceSelectedAll = false;
          // console.log('nononon11111111111111ono')
        }else{
          this.sourceSelectedAll = this.isSelectedAll(this.sourceList);
          // console.log('yyyyyyyyyyyyy')
        }
      }

      //  如果  m==2  代表  选 区域   n 代表 第几级  i  当前  下标
      if(m == 2){
        //  如果  第一级  
        if(n === 1){
          
          //  清空 下标
          this.areaIndex2 = this.areaIndex3 = -1 ;
          //  判断  当前 点的是不是 刚才点的  
          // 如果不是  清空   第三级  的  当前数据   
          if(this.areaIndex1 !== i){
            this.areaNowList3 = [];
          }
          //  设置 index1  以判断 下次 点击 是不是 同一个
          this.areaIndex1 = i;
          //  设置  选没选中
          this.areaList1[i].selected = !this.areaList1[i].selected ;
          //   判断  是否 全选
          this.selectAllArea = this.isSelectedAll(this.areaList1);
          //    计算  第二级  当前  列表数据 areaNowList2
          if(!this.areaList1[i].selected){
          //  如果 当前 没选中   就把   二级 列表中  当前列表   遍历 找到 REGION = 一级列表 i 对应的 REGION值 删除
            this.delete(this.areaNowList2,'REGION',this.areaList1[i].REGION);
          //  把   二级 列表中  实际列表   遍历 找到 REGION = 一级列表 i 对应的 REGION值 selected 改false
            this.changeSelect(this.areaList2,'REGION',this.areaList1[i].REGION,false);
            // console.log(this.areaList1[i].REGION);
          }else{
            //  如果当前选择了  则 到 实际值中  找到 对应的元素  插到  对应的列表 当前 二级列表 前面   并且设置 true
            // this.changeSelect(this.areaList2,'REGION',this.areaList1[i].REGION,true);
            this.add(this.areaList2,'REGION',this.areaList1[i].REGION,this.areaNowList2);
            // console.log('当前 选中的 区  包含 的省',this.areaNowList2)
          }

          // console.log(this.areaList2);
          // console.log(this.areaNowList2);


        }
        //  如果 点击的 是 第二级
        if(n == 2){
          this.areaIndex3 = -1;
          this.areaNowList2[i].selected = !this.areaNowList2[i].selected ;
          // console.log(this.areaList2);
          // console.log(this.areaNowList2);

          if(!this.areaNowList2[i].selected){
            // 如果 当前 没选中  清空  第三级   当前的数据
            this.areaNowList3 = [];
            // 并且  更改  全部 选中 为否   并且 清空 选中 里面 的 数据
            this.changeSelect(this.areaList3 , 'PROVINCE' , this.areaNowList2[i].PROVINCE , false);


          }else{
            var result = this.findData(this.areaList3,'PROVINCE',this.areaNowList2[i].PROVINCE);
            console.log('找第三级列表  有没有 当前选中的省份 对应的数据 得到的数组 ',result);

            if(result.length == 0){
              console.log('请求 经销商 的数据---  ',this.areaNowList2[i].PROVINCE);
              // console.log('canshu',this.params)
              // this.$store.commit('setParams',{provice:this.areaNowList2[i].PROVINCE});
              //  如果 没有  就发请求  获取 当前省份 对应的 经销商 数据 【】【】【】【】【】【】【】【】【】【】
              this.$http.getSellers(this.params).then(res=>{
                if(!!res.status){
                  //  逐个 注入 selected 属性   并且  给  list3
                  this.areaList3 = this.addSelected(res.data)
                  //  当前 显示 的  就等于   去list3中找  找到  与当前 省份 对应的数据
                  this.areaNowList3 = this.findData(this.areaList3,'PROVINCE',this.areaNowList2[i].PROVINCE);

                  // 并且  更改  全部 选中  并且 加入 到选中 里面
                  this.changeSelect(this.areaNowList3 , 'PROVINCE' , this.areaNowList2[i].PROVINCE , true);

                  // for(let tmp of  this.areaNowList3 ){
                  //   this.areaSelectedList3.push(tmp.DEALER_CODE)
                  // }
                  // this.add(list,key,val,nowList)
                  
                }
              })
    

            }else{

              this.areaNowList3 = this.clone(result);
              //  并且 都选中
              this.changeSelect(this.areaNowList3 , 'PROVINCE' , this.areaNowList2[i].PROVINCE , true);
              this.changeSelect(this.areaList3 , 'PROVINCE' , this.areaNowList2[i].PROVINCE , true);

            }



          }

        }
        //  如果 选中了  第三级
        if( n==3 ){
          this.areaNowList3[i].selected = !this.areaNowList3[i].selected;
          for(let tmp of this.areaList3){
            if(tmp.DEALER_CODE == this.areaNowList3[i].DEALER_CODE){
              tmp.selected = this.areaNowList3[i].selected
            }
          }

          // this.changeSelect();
        }


      }
      
      
    },

    //  车系  确认
    onConfirmCar(){
      this.closedDopdownMenu(2);
      let seriesId = this.findValToList(this.carList,'selected',true,'SERIES_ID');
      seriesId = seriesId.toString();
      console.log('选中的车系 数据是 +++++++++++++++++++++ ',seriesId);
      this.$store.commit('setParams',{seriesId});
      // console.log('params----- ',this.$store.getters.params,this.$store.getters.dataType)

      if(!this.carSelectedAll){

        let str = String(this.findValToList(this.carList,'selected',true,'SERIES_NAME'));
        this.car = !str ? '车系' : str;

      }else{
        this.car = '全选'
      }


    },

    // 渠道 确认
    onConfirmSource(){
      this.closedDopdownMenu(4);
      // console.log(this.sourceList);

      let lable = this.findValToList(this.sourceList,'selected',true,'CLUE_NAME');
      lable = String(lable);
      console.log('++++++ 当前  选中  渠道列表【+++++++】',lable);
      this.$store.commit('setParams',{lable});

      if(!this.sourceSelectedAll){

        let str = String(this.findValToList(this.sourceList,'selected',true,'CLUE_NAME'));
        this.lable = !lable ? '渠道分析' : str;

      }else{
        this.lable = '全选'
      }




    },




    // 确认 区域  按钮
    onConfirm(n){
      // console.log(n);


      let region = this.findValToList(this.areaList1,'selected',true,'REGION');
      region = String(region);

      let provice = this.findValToList(this.areaList2,'selected',true,'PROVINCE');
      provice = String(provice);

      let dealerCode = this.findValToList(this.areaList3,'selected',true,'DEALER_CODE');
      dealerCode = String(dealerCode);

      // console.log('++++++ 经销商 列表 +++++++',this.areaList3);
      // console.log('++++++ 当前  经销商 列表 +++++++',this.areaNowList3);PROVINCE
      // console.log('++++++ 当前  选中  地区 列表 ',region);
      // console.log(' 当前  选中  省份 列表 +++++++',provice);
      // console.log('++++++ 当前  选中  经销商 code 列表 +++++++',dealerCode);

      this.$store.commit('setParams',{dealerCode,region,provice});

      if(!this.selectAllArea){

        let str1 = String(this.findValToList(this.areaList3,'selected',true,'DEALER_SHORTNAME'));
        let str2 = String(this.findValToList(this.areaList2,'selected',true,'PROVINCE'));
        let str3 = String(this.findValToList(this.areaList1,'selected',true,'REGION'));
        console.log('经销商 名字 集合 ',str1,str2,str3);
        console.log('级别',this.userLevel);
        if(this.userLevel == 1){

        }
        let area = str1 + str2 + str3;
        this.area = !area ? '区域' : area;

      }else{
        this.area = '全国'
      }



      this.closedDopdownMenu(n);
      
    },



    //  复用的方法

    //  把  list 所有的 属性k 为 val 的 数据 的  key的值  找出  返回到新 数组里  findTrue
    findValToList(list,k,v,key){
      let arr = [];
      for(let tmp of list){
        if(tmp[k] == v){
          arr.push(tmp[key])
        }
      }
      return arr
    },

    //  查询  第三级 实际 列表  有没有 当前省份的数据  如果有  就返回 所有对应的数据  可能为空  
    findData(list,key,val){
      var arr = [];
      for(let i=0;i<list.length;i++){
        if(list[i][key] === val){
          arr.push(list[i])
        }
      }
      return arr
    },
    //  将 key 的 值 === 传过来的值 的数据  拼接到  对应的 list   
    add(list,key,val,nowList){
      
      for(let i=0;i<list.length;i++){
        if(list[i][key] === val){
          nowList.unshift(list[i]);
        }
      }
    },
    // 按属性 修改  对应列表 中  对应的元素 的selected 的值
    changeSelect(list,key,val,bool){
      for(let i=0;i<list.length;i++){
        if(list[i][key] === val){
          list[i].selected = bool;
        }
      }
    },
    // 按属性  删除  列表 中  对应的元素
    delete(list,key,val){
      for(let i = list.length-1;i>=0;i--){
        if(list[i][key] === val){
          list.splice(i,1);
        }        
      }
    },

    // 遍历  注入  selected 属性  默认为  false
    addSelected(list){
      for(let tmp of list){
        tmp.selected = false;
      }
      return list;
    },
    // 根据 下级list是否每个都 true 判断  全选  非全选  
    isSelectedAll(list){
      for(let tmp of list){
        if(!tmp.selected){
          return false;
        }
      }
      return true;
    },
    //  根据  全选按钮   控制 list 内 每个元素的 selected状态
    selectAll(list,val){
      for(let tmp of list){
        tmp.selected = val;
      }
    },

    // 关闭  下拉菜单
    closedDopdownMenu(i){
      this.$refs['item'+i].toggle();
    },

    // 克隆
    clone(obj){
      if(obj === null)return null
      if(Object.prototype.toString.call(obj) === '[object Array]'){
        var newArr = [];
        for(let tmp of obj){
          if(typeof tmp !== 'object'){
            newArr.push(tmp)
          }else{
            newArr.push(this.clone(tmp))
          }
        }
        return newArr;
      }
      var newObj = {};
      for(let key in obj){
        if(typeof obj[key] !== 'object'){
          newObj[key] = obj[key]
        }else{
          newObj[key] = this.clone(obj[key])
        }
      }
      return newObj
    },
    //  
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`
      }
      return value;
    },
  },

}
</script>
<style >
  .van-dropdown-menu__title{
    padding:0 12px 0 4px;
  }
  .van-dropdown-menu__title::after{right:2px}
</style>
<style scoped>
  
  
  .box{height:270px;}
  .text_l{ text-align: left}
  .text_c{ text-align: center}
  .text_r{ text-align: right}

  .h_44{height:30px;line-height:30px}
  .m_20{margin:0 20px;}

  .dropdown_box{padding:10px 30px;}
  .bg_light{ background-color: #D5E6F0}
  .m_t_6{ margin-top:6px;}
  .m_t_10{ margin-top:10px;}
  .m_b_6{ margin-bottom:6px;}
  .m_b_10{ margin-bottom:10px;}


  .bg_light.selected{background-color: #95CBF2}


  /* 区域 三级菜单 */
  .dropdown_box{
    font-size:16px;
    color:#666;
    text-align:center;
    padding:10px 30px 55px 30px;
    height:100%;
    -webkit-box-sizing: border-box;
    -o-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
  }
  .dropdown_box.dropdown_box1{
    height:350px;
    padding:0;
    padding-bottom:50px;
  }
  .scroll_box{
    overflow-y: auto;
    height:300px;
    padding-top:35px;
  }
  .pb_60{padding-top:0;padding-bottom:60px;}
  .scroll_box1{
    height:100%;
    overflow-y: auto;
  }
  
  .border_right{
    border-right:1px solid #aaa;
  }
  .pos_t{
    position:absolute;
    top:0;
    width:33.33333%;
    height:35px;
    line-height:35px;
    font-weight: bold;
  }
  .item{
    padding:3px 12px;
  }
  .item.select{
    background-color:#1E81D2;
    color:#fff;
    border-radius:5px;
  }
  .flex{
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>
