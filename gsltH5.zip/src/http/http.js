
import axios from 'axios';
import QS from 'qs';
import {Toast} from 'vant';
import store from '@/store/index';
//  引入  全局  函数  变量 等
import GLO from '../global'


//  设置  地址
// axios.defaults.baseURL = 'http://localhost:888';
// axios.defaults.baseURL = 'http://172.16.99.230/dmscloud.KPI/KPI';
// axios.defaults.baseURL = 'http://222.240.163.135/dmscloud.KPI/KPI';
// axios.defaults.baseURL = 'http://119.39.118.148/dmscloud.KPI/KPI';

axios.defaults.baseURL = GLO.BaseUrl;

// axios.defaults.baseURL = '';

// 请求 超时 时间
axios.defaults.timeout = GLO.MaxConnectTime; 

// 请求头
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
axios.defaults.withCredentials = true;

axios.interceptors.request.use(
  config=>{
    // console.log("进入请求拦截器...");
    
    // if(config.method==="post"){
    //   config.data=qs.stringify(config.data)
    // }

    // let jwt = '';
    // let arr = document.cookie.split("; ");
    // let cookies = [];
    // for(let tmp of arr){
    //   let key = tmp.split('=')[0];
    //   let obj = {};
    //   obj[key] = tmp.split('=')[1];
    //   cookies.push(obj);
    // }
    // for(let tmp of cookies){
    //   if(!!tmp['jwt']){
    //     jwt = tmp['jwt'];
    //   }
    // }

    // if(!!jwt){
      // config.headers.jwt = 'eyJ0eXBlIjoiSldUIiwiYWxnIjoiUlM1MTIifQ.eyJ1aWQiOiIxXzdjMmE1M2FiLTRmODAtNGQwOS04YjcwLWVlM2RkZDY3YmI2OSIsIkVOVElUWV9DT0RFIjoiVEVOQU5UXzEifQ.KbkkqLT9CCdTh5FCL8NUobwnRrl9qoJAF2OlOATAXx-3FTzvKnhDzM-9DHPQ7Efdyj_XDOz-tH1-JyhSGzy6tglGfcsu6wqr0WThWDkUXbS1UI-U6v0yMEroqvKJpCV5nHZuvt7tCe1HMgkx1J7k6JaHCeUwGvmcps7uAnnguj0';
    // }
    // document.cookie = 'jwt=eyJ0eXBlIjoiSldUIiwiYWxnIjoiUlM1MTIifQ.eyJ1aWQiOiIxX2NkN2M5MmRlLWVlNTYtNDMwYi04Y2I1LTU0MDBkZGE3MmYxYSIsIkVOVElUWV9DT0RFIjoiVEVOQU5UXzEifQ.BGB1v-Rxi_-pb43lLc0p0y-dcfiptyGQJNMDKmWDZJkvPbYgHrb3N8Grhc58_iie-4bjeGIAbaODQU4B_vSs8twycu_vkXf23al6U_mEg2BqkKCO2nD2foJbLsjUHl1KryVR5nEx3_Oapj5-DAX53vt0oVWa1sb6GlHRqCKlKJ8'
    


    // if(localStorage.getItem("jwt")){
    // config.headers.jwt=localStorage.getItem("jwt");
    // config.headers.jwt = 'eyJ0eXBlIjoiSldUIiwiYWxnIjoiUlM1MTIifQ.eyJ1aWQiOiIxX2NkN2M5MmRlLWVlNTYtNDMwYi04Y2I1LTU0MDBkZGE3MmYxYSIsIkVOVElUWV9DT0RFIjoiVEVOQU5UXzEifQ.BGB1v-Rxi_-pb43lLc0p0y-dcfiptyGQJNMDKmWDZJkvPbYgHrb3N8Grhc58_iie-4bjeGIAbaODQU4B_vSs8twycu_vkXf23al6U_mEg2BqkKCO2nD2foJbLsjUHl1KryVR5nEx3_Oapj5-DAX53vt0oVWa1sb6GlHRqCKlKJ8';

    
    config.headers.jwt = GLO.getCookie('jwt');

    // console.log('http中的 jwt  ',GLO.getCookie('jwt'));

    // config.headers.jwt = jwt;

    // }
    // if(sessionStorage.getItem("jwt")){
    //   config.headers.jwt=sessionStorage.getItem("jwt");
    // }
    return config;
  },
  error=>{
    console.log("===请求拦截器报错===")
    console.log(error);
    console.log("===end===");
    Promise.reject(error);
  }
);
axios.interceptors.response.use(
  res=>{
    // console.log("触发响应拦截器...")
    // if(res.data.status==403){
    //   localStorage.removeItem("token");
    //   sessionStorage.removeItem("token");
    //   // store.commit("setIslogin",false);
    //   // store.commit("setUname","");
    // }else if(res.data.code==-1){
    //   store.commit("setIslogin",false);
    //   store.commit("setUname","");
    //   //alert(res.data.msg+" 请先登录 !");
    // }else if(res.data.token){
    //   store.commit("setUname",res.data.uname);
    //   store.commit("setIslogin",true);
    //   if(res.remember==="true"){
    //     localStorage.setItem("token",res.data.token);
    //   }else{
    //     sessionStorage.setItem("token",res.data.token);
    //   }
    // }

    
    if(res.data.status == 200){
      console.log('返回的 jwt ',res.data.jwt);
      // document.cookie = 'jwt=eyJ0eXBlIjoiSldUIiwiYWxnIjoiUlM1MTIifQ.eyJ1aWQiOiIxXzdjMmE1M2FiLTRmODAtNGQwOS04YjcwLWVlM2RkZDY3YmI2OSIsIkVOVElUWV9DT0RFIjoiVEVOQU5UXzEifQ.KbkkqLT9CCdTh5FCL8NUobwnRrl9qoJAF2OlOATAXx-3FTzvKnhDzM-9DHPQ7Efdyj_XDOz-tH1-JyhSGzy6tglGfcsu6wqr0WThWDkUXbS1UI-U6v0yMEroqvKJpCV5nHZuvt7tCe1HMgkx1J7k6JaHCeUwGvmcps7uAnnguj0'

      // localStorage.setItem("jwt",res.data.jwt);
      // sessionStorage.setItem("jwt",res.data.jwt);
    }else if(res.data.status == 403){
      // localStorage.removeItem("jwt");
      // sessionStorage.removeItem("jwt");
    }
    return res;
  },
  error=>{
    
  }
)

// axios.interceptors.request.use(req => {
//   // const str = '?token=' + localStorage.getItem('token')
//   // req.url += str
//   // console.log('请求信息:',req)
//   return req
// })

// axios.interceptors.response.use(res => {
//   if (!res.data) {
//     return Toast.fail('没有数据')
//   }
//   return res
// })

// // 请求 拦截器
// axios.interceptors.request.use(    
// config => {        
//   // 每次发送请求之前判断vuex中是否存在token        
//   // 如果存在，则统一在http请求的header都加上token，这样后台根据token判断你的登录情况
//   // 即使本地存在token，也有可能token是过期的，所以在响应拦截器中要对返回状态进行判断 
//   const jwt = localStorage.getItem('jwt');        
//   jwt && (config.headers.Authorization = jwt);        
//   return config;    
// },    
// error => {        
//     return Promise.error(error);    
// })


// //  响应 拦截器
// axios.interceptors.response.use(    
//   response => {   
//       // 如果返回的状态码为200，说明接口请求成功，可以正常拿到数据     
//       // 否则的话抛出错误
//       if (response.status === 200) {            
//           return Promise.resolve(response);        
//       } else {            
//           return Promise.reject(response);        
//       }    
//   },    
//   // 服务器状态码不是2开头的的情况
//   // 这里可以跟你们的后台开发人员协商好统一的错误状态码    
//   // 然后根据返回的状态码进行一些操作，例如登录过期提示，错误提示等等
//   // 下面列举几个常见的操作，其他需求可自行扩展
//   error => {            
//       if (error.response.status) {            
//           switch (error.response.status) {                
//               // 401: 未登录
//               // 未登录则跳转登录页面，并携带当前页面的路径
//               // 在登录成功后返回当前页面，这一步需要在登录页操作。                
//               case 401:                    
//                   router.replace({                        
//                       path: '/login',                        
//                       query: { 
//                           redirect: router.currentRoute.fullPath 
//                       }
//                   });
//                   break;

//               // 403 token过期
//               // 登录过期对用户进行提示
//               // 清除本地token和清空vuex中token对象
//               // 跳转登录页面                
//               case 403:
//                    Toast({
//                       message: '登录过期，请重新登录',
//                       duration: 1000,
//                       forbidClick: true
//                   });
//                   // 清除token
//                   localStorage.removeItem('token');
//                   store.commit('loginSuccess', null);
//                   // 跳转登录页面，并将要浏览的页面fullPath传过去，登录成功后跳转需要访问的页面 
//                   setTimeout(() => {                        
//                       router.replace({                            
//                           path: '/login',                            
//                           query: { 
//                               redirect: router.currentRoute.fullPath 
//                           }                        
//                       });                    
//                   }, 1000);                    
//                   break; 

//               // 404请求不存在
//               case 404:
//                   Toast({
//                       message: '网络请求不存在',
//                       duration: 1500,
//                       forbidClick: true
//                   });
//                   break;
//               // 其他错误，直接抛出错误提示
//               default:
//                   Toast({
//                       message: error.response.data.message,
//                       duration: 1500,
//                       forbidClick: true
//                   });
//           }
//           return Promise.reject(error.response);
//       }
//   }    
// );



//  get 请求

export function get(url, params){   
  // console.log('请求 get  方法'); 
  return new Promise((resolve, reject) =>{        
    axios.get(url, {            
          params: params        
      }).then(res => {
          resolve(res.data);
      }).catch(err =>{
          reject(err.data)        
      })    
  });
}

export function get1(url, params){   
  // console.log('请求 get  方法'); 
  return new Promise((resolve, reject) =>{     
    axios.defaults.baseURL = '';   
    axios.get(url, {            
          params: params        
      }).then(res => {
          resolve(res.data);
      }).catch(err =>{
          reject(err.data)        
      })    
  });
}

//  post  请求
export function post(url, params) {
  // console.log('请求 post  方法'); 
  return new Promise((resolve, reject) => {
    axios.post(url, QS.stringify(params))
      .then(res => {
          resolve(res.data);
      })
      .catch(err =>{
          reject(err.data)
      })
  });
}

//  post1  请求
export function post1(url, params) {
  // console.log('请求 post  方法'); 
  return new Promise((resolve, reject) => {
    axios.defaults.baseURL = '';
    axios.post(url, QS.stringify(params))
      .then(res => {
          resolve(res.data);
      })
      .catch(err =>{
          reject(err.data)
      })
  });
}

