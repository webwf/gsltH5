
import { get,get1, post,post1 } from './http';

// export const getIndex = p => get('/', p)

export default {
  //  获得 绝对量  数据
  getAbs (params) {
    return get('/dmscloud.KPI/KPI/getOemSaleKpi/appAuthCas', params)
  },
  //  获得 车系 数据
  getSeries (params) {
    return get('/dmscloud.KPI/KPI/getOemSaleKpiSeries/appAuthCas', params)
  },
  //  获得  渠道  数据
  getSrc (params) {
    return get('/dmscloud.KPI/KPI/getOemSaleKpiSource/appAuthCas', params)
  },
  //  获取  同比 环比 数据
  getCompare (params) {
    return get('/dmscloud.KPI/KPI/getSaleCompare/appAuthCas', params)
  },
  //  获取  区域
  getRegio (params) {
    return get('/dmscloud.KPI/KPI/getRegion//appAuthCas', params)
  },
  //  获取  省份
  getProvince (params) {
    return get('/dmscloud.KPI/KPI/getALLRegionPro/appAuthCas', params)
  },
  //  获得 车系  列表
  getSeriesList (params) {
    return get('/dmscloud.KPI/KPI/getALLSeries/appAuthCas', params)
  },
  //  获得 渠道  列表
  getLabelList (params) {
    return get('/dmscloud.KPI/KPI/queryOneLevelLabel/appAuthCas', params)
  },
  //  获得 经销商  列表
  getSellers (params) {
    return get('/dmscloud.KPI/KPI/getALLDealer/appAuthCas', params)
  },




  //  获得   总 积分  
  getTotalIntegral (params) {
    return get('/dmscloud.shopPC/appIntergral/intergral', params)
  },
  //  获得 积分 详情  
  getIntegralDetail (params) {
    return get('/dmscloud.shopPC/appIntergral/getIntergralDetail', params)
  },
  //  获得 待审核 数据 
  getIntegralCheckData (params) {
    return get('/dmscloud.shopPC/appIntergral/getIntergralAudit', params)
  },
  //  请求  审核   
  requestCheck (params) {
    return get('/dmscloud.shopPC/appIntergral/intergralAudit', params)
  },

  //  获得去  jd  的参数
  getJDParams (params) {
    return get('/dmscloud.shopPC/jd/login/appAuthCas', params)
  },
  //  获得去  SN 的参数
  getSNParams (params) {
    return get('/dmscloud.shopPC/sn/login', params)
  },


  //  请求  jd  
  // getJDResponse (params) {
  //   return post('/http://ydh.jd.com/L_58I7LjXhaQXU9FLNP6Ug==/autoLogin', params)
  // },


  //  请求  sn  
  getSNResponse (url,params) {
    return post1(url, params)
  },
  
  //  请求  test  
  getTest (url,params) {
    return get1(url, params)
  },


}

