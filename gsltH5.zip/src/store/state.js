const state = {
  params:{
    time:'',  // 月份
    appRole:10061030, //
    region:'',  // 地区
    provice:'',   //  省份
    lable:'',   // 渠道 名
    seriesId:'',  // 车系 id
    mark:1,   // 大区/省份/经销商
    dealerCode:'',  // 经销商 编码 
    pageNumber:1,
    pageSize:10
  },
  //  数据 类 型  ---  绝对量/车系/来源渠道
  dataType : 1,
  //  绝对量   车系  来源渠道  数据
  absData : [],
  seriesData : [],
  sourceData : [],
  // 零售 比值
  compareData : {},

  //渠道 列表
  lableList:[],
  //车系 列表
  // seriesList:[],

  // 用户 级别
  userLevel:-1,

  pno:0,
}
export default state