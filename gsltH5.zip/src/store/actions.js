const actions = {
  // add(context, param) {
  //   // context.state.abcd += param.n;
  //   context.commit('add', context.state.abcd)//提交改变后的state.count值
  // },
  // incrementStep({state, commit, rootState}) {
  //     if (rootState.count < 100) {
  //         store.dispatch('add', {//调用increment()方法
  //             step: 10
  //         })
  //     }
  // },


  // getAbs(context){
  //   this.$http.getAbs({time:'2019-06',appRole:10061030}).then(res=>{
  //     console.log(res);
  //     if(!!res.status){
  //       context.commit('setAbs', res.data)
  //     }
  //   })
  // }



}
export default actions