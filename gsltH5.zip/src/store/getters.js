const getters = {
  params(state){
    return state.params
  },

  abs(state){
    return state.absData
  },

  series(state){
    return state.seriesData
  },

  source(state){
    return state.sourceData
  },

  dataType(state){
    return state.dataType
  },

  compareData(state){
    return state.compareData
  },
  // 渠道 列表
  lableList(state){
    return state.lableList
  },
  // 车系 列表
  // seriesList(state){
  //   return state.seriesList
  // },
  // 账号 级别
  userLevel(state){
    return state.userLevel
  },
  pno(state){
    return state.pno
  },
}
export default getters