const mutations = {
  //  参数
  setParams(state,data){
    // console.log('调用了 set params 方法 ')
    for(let key in data){
      state.params[key] = data[key];
    }

    state.userLevel = state.params.appRole == 10061030 ? 1 : state.params.appRole ==10061029 ? 2 : state.params.appRole == 10061022 ? 3 : 0;
    // console.log(state.params);
  },
  //  绝对值  数据
  setAbs(state,data){
    state.absData = data;
  },
  //  车系 数据
  setSeries(state,data){
    state.seriesData = data;
  },
  // 来源渠道  数据
  setSource(state,data){
    state.sourceData = data;
  },
  //  绝对量 1  车系 2  来源渠道 3
  setDataType(state,n){
    state.dataType = n;
  },
  //  零售 比值
  setCompareData(state,data){
    state.compareData = data;
  },
  //  渠道 列表
  setLableList(state,data){
    state.lableList = data;
  },
  //  车系 列表
  // setSeriesList(state,data){
  //   state.seriesList = data;
  // },

  setPno(state,data){
    state.pno = data;
  },

}
export default mutations