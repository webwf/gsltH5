  //  设置  地址
// const BaseUrl = 'http://localhost:888';
// const BaseUrl = 'http://172.16.99.230/dmscloud.KPI/KPI';
// const BaseUrl = 'http://222.240.163.135/dmscloud.KPI/KPI';
// const BaseUrl = 'http://119.39.118.148/dmscloud.KPI/KPI';

const BaseUrl = 'api';

// const BaseUrl = '';

//  跳转到 京东  的  url
const JdUrl = 'http://ymes.jd.com/L_58I7LjXhaQXU9FLNP6Ug==/autoLogin';


// 请求 超时 时间
const MaxConnectTime = 10000; 

const loadingMsg = '加载中，请稍候...';
const reLoadingMsg = '重新加载中，请稍候...';
const jumpMsg = '跳转中，请稍候...';








  // 克隆
function clone(obj){
    // console.log('调用 父组件的 clone 方法',obj);
  if(obj === null)return null
  if(Object.prototype.toString.call(obj) === '[object Array]'){
    var newArr = [];
    for(let tmp of obj){
      if(typeof tmp !== 'object'){
        newArr.push(tmp)
      }else{
        newArr.push(this.clone(tmp))
      }
    }
    return newArr;
  }
  var newObj = {};
  for(let key in obj){
    if(typeof obj[key] !== 'object'){
      newObj[key] = obj[key]
    }else{
      newObj[key] = this.clone(obj[key])
    }
  }
  return newObj
}



//  得到 url  存到 cookie 中
function urlToCookie(url){
  let arr = url.split('&');
  for(let tmp of arr){
    this.setCookie(tmp.split('=')[0],tmp.split('=')[1])
  }
  // console.log(document.cookie);
}


//  设置 cookie
//  参数（key  val  有效时间）
function setCookie(name, value, liveMinutes) {  
  if (liveMinutes == undefined || liveMinutes == null) {
    liveMinutes = 60 * 2;
  }
  if (typeof (liveMinutes) != 'number') {
    liveMinutes = 60 * 2;//默认120分钟
  }
  var minutes = liveMinutes * 60 * 1000;
  var exp = new Date();
  exp.setTime(exp.getTime() + minutes + 8 * 3600 * 1000);
  //path=/表示全站有效，而不是当前页
  document.cookie = name + "=" + value + ";path=/;expires=" + exp.toUTCString();
}


//获取cookie
// getCookie('id');

function getCookie(Name) {
   var search = Name + "="//查询检索的值
   var returnvalue = "";//返回值
   if (document.cookie.length > 0) {
     let sd = document.cookie.indexOf(search);
     if (sd!= -1) {
        sd += search.length;
        let end = document.cookie.indexOf(";", sd);
        if (end == -1)
         end = document.cookie.length;
         //unescape() 函数可对通过 escape() 编码的字符串进行解码。
        returnvalue=unescape(document.cookie.substring(sd, end))
      }
   }
   return returnvalue;
}


//获取cookie
// getCookie('id');

function removeCookie(Name) {
  var exp = new Date();
  exp.setTime(exp.getTime() - 1);
  var cval = this.getCookie(name);
  if (cval != null) {
      document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
  };
}








export default{
  BaseUrl,
  JdUrl,
  MaxConnectTime,
  loadingMsg,
  reLoadingMsg,
  jumpMsg,





  urlToCookie,
  setCookie,
  getCookie,
  removeCookie,
  clone,
}



